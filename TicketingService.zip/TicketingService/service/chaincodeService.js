﻿'use strict';

var Client = require('node-rest-client').Client;
var config = require('config');
var client = new Client();
var fs = require('fs');
var configDetails = fs.readFileSync('config/config.json', 'utf8');
var configData = JSON.parse(configDetails);
var request = require('async-request');
var request2 = require('request-promise');
var constants = require('../config/constants.js');
var logHelper = require('../utils/logging.js');
var logger = logHelper.getLogger(config.processname);
const FormData = require('form-data');
const pinataSDK = require('@pinata/sdk');
const pinata = pinataSDK('5fb6c023dd18de9d6308', 'c2fa1f640e018c2c0f64656527eb394365e5edfee1380ab416185807bfbae912');

const axios = require('axios');


module.exports = {
    
    uploadFile: uploadFile
    
}

/**
 * This method is used to invoke the data
 * @param {*} fabricToken 
 * @param {*} reqBodyData 
 * @param {*} chainName 
 * @param {*} functionname 
 * 
 * 
 */
 async function uploadFile2(filename) {
  
 const readableStreamForFile = fs.createReadStream('./images/'+filename);
 const options = {
     pinataMetadata: {
         name: filename,
         keyvalues: {
             customKey: 'customValue',
             customKey2: 'customValue2'
         }
     },
     pinataOptions: {
         cidVersion: 0
     }
 };
 pinata.pinFileToIPFS(readableStreamForFile, options).then((result) => {
     //handle results here
     console.log(result);
 }).catch((err) => {
     //handle error here
     console.log(err);
 });
}
 async function uploadFile5(filename) {
    console.log("---vikas---")
//const readableStreamForFile = fs.createReadStream('./1.jpg');
//console.log("---readableStreamForFile",readableStreamForFile)
//let data = new FormData();
    //data.append('file', fs.createReadStream(filename));
   // data.append('file', JSON.stringify(readableStreamForFile.buffer));
   // console.log("data----",data)
   const body = {
    message: 'Pinatas are awesome'
};
console.log("---body",body);
const options = {
    pinataMetadata: {
        name: "vikas",
        keyvalues: {
            customKey: 'customValue',
            customKey2: 'customValue2'
        }
    },
    pinataOptions: {
        cidVersion: 0
    }
};
console.log("---options---",options)
pinata.pinJSONToIPFS(body, options).then((result) => {
    //handle results here
    console.log(result);
}).catch((err) => {
    //handle error here
    console.log(err);
});
}
async function uploadFile(filename) {
    var body1 = JSON.stringify(filename);
    try {
     
    const url = 'https://api.pinata.cloud/pinning/pinFileToIPFS';
   let form = new FormData();
   form.append('file', filename.buffer, filename.originalname);
 //  form.append('file',filename.buffer);
   // let data = new FormData();
    //data.append('file', fs.createReadStream(filename));
   // data.append('file', body1);
    console.log("data----",form)
    
    return axios
        .post(url, form, {
            maxBodyLength: 'Infinity', //this is needed to prevent axios from erroring out with large files
            headers: {
                'Content-Type': `multipart/form-data; boundary=${form._boundary}`,
                pinata_api_key: '5fb6c023dd18de9d6308',
                pinata_secret_api_key: 'c2fa1f640e018c2c0f64656527eb394365e5edfee1380ab416185807bfbae912'
            }
        })
        .then(function (response) {
            console.log("-----response data--",response.data);
           return response;
        })
        .catch(function (error) {
            console.log("------res-----",error);
            return error;
        });
        
    }catch (error) {
        console.log(error);
     } 
}


async function uploadFile7(reqBodyData) {
   // logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE);
   var body1 = JSON.stringify(reqBodyData);
    let data = new FormData();
    //data.append('file', body1);
   // data.append('file', fs.createReadStream(body1));
    let form = new FormData();
   //form.append('file', Buffer.from(body1));
   form.append('file', "abc.txt");
    const url = 'https://api.pinata.cloud/pinning/pinFileToIPFS';
   // console.log("reqBodyDataupdate---", body1);
   

    try {
       // var url = configData.PDF_API_URL;
        var options = {
            method: constants.REQUEST_POST,
            maxContentLength: "infinity", 
            maxBodyLength: "infinity",
            uri: url,
          form,
            headers: {
                'Content-Type': 'multipart/form-data; boundary=${data._boundary}',
                'pinata_api_key': 'efd0a2a5f2c6709424d4',
                'pinata_secret_api_key': '3f8ed1316f5d5075feaa1aba1f01987304394f8a59f9f7d19c676f7802cb73a5'
               
            }
           
        };
        try {
            console.log("----PDF IMAGE --------------------------------------------", options)
            var response = await request2(options);
            logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, constants.RESPONSE, response);
            logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE);
            return Promise.resolve(response);
        } catch (error) {
            logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, error);
            Promise.reject(error);
        }
    } catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, error);
        return error;
    }
}
async function uploadFile2(file) {
    // alert('dkkdkdkd');
   var body1 = JSON.stringify(file);
   
     const url = 'https://api.pinata.cloud/pinning/pinFileToIPFS';
    //const file1 = fs.createReadStream(file);
     let data = new FormData();
     //data.append('file', body1)
     data.append("file", fs.createReadStream(body1));
   console.log("data----",data)
     return axios
       .post(url, data, {
         maxContentLength: 'Infinity',
         headers: {
           'Content-Type': 'multipart/form-data; boundary=${data._boundary}',
           // pinata_api_key: '994e8320b0e94b0e7f82',
          pinata_api_key: 'efd0a2a5f2c6709424d4',
         //  pinata_secret_api_key: '2e86502f1689e445b1b2e3063080aed37a6110f365bc25e83ab14080fae61db7'
          pinata_secret_api_key: '3f8ed1316f5d5075feaa1aba1f01987304394f8a59f9f7d19c676f7802cb73a5',
     
         }
       })
       .then(function (response) {
         const y = response.data.IpfsHash
         return y
       })
       .catch(function (error) {
         console.log(error)
       return error
       });
   }