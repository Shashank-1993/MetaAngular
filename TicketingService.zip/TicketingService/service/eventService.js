'use strict';
var fs = require('fs'); 
var configDetails = fs.readFileSync('config/config.json','utf8');
var chaincodeService = require('./chaincodeService');

var configData = JSON.parse(configDetails);
var config = require('config');
var constants = require('../config/constants.js');
var logHelper = require('../utils/logging.js');
var logger = logHelper.getLogger(config.processname);

var util = require('../utils/util.js');
var validation = require('../utils/validation_helper');
var db = require('../api/helpers/CouchDBCommon.js');

module.exports = {
  
  createEvent:createEvent,
  getAllEvent:getAllEvent
    
}



async function createEvent(req,requestBody) {
//  console.log("inside service=============",requestBody.eventdetails);
  ///console.log("inside service1111=============",requestBody.eventdetailsl.eventName);
 
 const reqBody1 = JSON.parse(requestBody.eventdetails);
 console.log("reqBody1--------",reqBody1)
 var reqBody={};  
 try {
            
      //const uploadpics = req.files.myfile;
      //const uploadpics = req.files.myfile;
        //var filename = uploadpics[0].originalname;
        var eventId = util.generateId(constants.EVENT_ID);
     const uploadpics2 = req.swagger.params.myfile.value;
     var resp = await chaincodeService.uploadFile(uploadpics2);
     console.log("--resp-------------",resp.data);
     var ipfsres=resp.data;
     //reqBody['eventId'] = eventId;
     //reqBody['eventName'] = reqBody1.eventName;
     //reqBody['sellerName'] = reqBody1.eventDescription;
     //reqBody['imageHash'] = ipfsres.IpfsHash;
     reqBody = {
      eventId: eventId,   
      eventName: reqBody1.eventName,
      eventDescription:reqBody1.eventDescription,
      eventDate:reqBody1.eventDate,
      imageHash: ipfsres.IpfsHash,
      userId: 'Ashley',
      eventFlag:'true'
     }
     console.log("finalresbody+++++++++++++",reqBody)
     var result = await db.save(reqBody);
   
    // return resp.data;
    // const uploadpics =   new Buffer(req.swagger.params.myfile.value, 'binary').toString('base64');
     //console.log("uploadpics----",uploadpics);
     //var filename = uploadpics[0];
//uplod file

//var filename = uploadpics.originalname;
// var actulfileName = filename.split('.');
// const readData = JSON.parse(requestBody);
/*console.log("filename----",filename);
let path = './images';
 if (!fs.existsSync(path)) {
    fs.mkdirSync(path);
}
uploadpics.forEach(function (file) {
    var inputString = filename ;
     fs.writeFile(path + '/' + inputString, file.buffer, function (err) {
        if (err) {
            debug(err);
            var err = {
                message: 'File not uploaded'
            };
        }
    });
  });*/
//end upload
     
   //var resp = await chaincodeService.uploadFile(uploadpics2);
  //  console.log("--resp-------------",resp.data);
   //  return resp.data;
   if (Object.keys(result).length > 0) {
    logHelper.logMethodExit(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER);
    logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, constants.RESPONSE, result);
    return result;
}
  } catch (error) {
      logHelper.logError(logger, constants.ADD_BUYER, constants.ADD_BUYER, error);
      return ({ code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500 })
  }

}
async function getAllEvent(){
  logHelper.logMethodEntry(logger, constants.TRANSACTION_SERVICE_FILE, constants.GET_TRANSACTION_BY_ASSET_ID);
  logHelper.logDebug(logger, constants.TRANSACTION_SERVICE_FILE, constants.GET_TRANSACTION_BY_ASSET_ID, constants.REQUEST );
    try {
      var result = await db.find({"eventFlag":'true'});
      var resp = [];
      if (result.length > 0) {
        for(var i = 0; i < result.length; i++) {
          resp.push(result[i]);
        }
        logHelper.logDebug(logger, constants.TRANSACTION_SERVICE_FILE, constants.GET_TRANSACTION_BY_ASSET_ID, constants.RESPONSE, result);
        logHelper.logMethodExit(logger, constants.TRANSACTION_SERVICE_FILE, constants.GET_TRANSACTION_BY_ASSET_ID);
        return ({statusCode:constants.SUCCESS, result:resp});
      } else {
        return ({statusCode:constants.NO_CONTENT, result:resp});
      }
    }catch(error){
      logHelper.logError(logger, constants.TRANSACTION_SERVICE_FILE, constants.GET_TRANSACTION_BY_ASSET_ID, error);
      return ({code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500});

    }
  } 