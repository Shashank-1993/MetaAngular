var request = require('request');
var chai = require('chai');
var expect = require('chai').expect;
var config = require('config');
var logHelper = require('../utils/logging.js');
var logger = logHelper.getLogger(config.processname);
var fs = require('fs');
var configDetails = fs.readFileSync('test/testData.json', 'utf8');
var configData = JSON.parse(configDetails);
var constants = require('../config/constants.js');

var auth = {
    fa: "",
    sm: "",
    lt: "",
    ja: "",
    a:""
};

var caseIds = [];
var evidenceIds = [];
var itrCase=0;
var itrEvidence=0;
var itrState=0;
var stateId;

describe("route", function () {
    /**
     * Test User Authentication.
    */
     describe("Test User Authentication", function () {
        it('Test User Authentication for Field Agent.', function (done) {
            logHelper.logMethodEntry(logger, 'UserAuthentication', configData.BASE_URL + "user/authenticate");
            var jsonData = {
                userId: configData.auth.FA.userId,
                password: configData.auth.FA.password,
                subscriptionKey: configData.SUB_KEY
            };
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"]
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/authenticate", method: constants.REQUEST_POST, headers: headers, body: JSON.stringify(jsonData)}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'User Authentication', "authenticate FA", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body); 
                    auth['fa'] = res.token;
                    expect(res.token).to.not.equal(null);
                    expect(resp.statusCode).to.equals(200);
                    done();
                }
            });
        });
        it('Test User Authentication for Store Manager.', function (done) {
            logHelper.logMethodEntry(logger, 'UserAuthentication', configData.BASE_URL + "user/authenticate");
            var jsonData = {
                userId: configData.auth.SM.userId,
                password: configData.auth.SM.password,
                subscriptionKey: configData.SUB_KEY
            };
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"]
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/authenticate", method: constants.REQUEST_POST, headers: headers, body: JSON.stringify(jsonData)}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'User Authentication', "authenticate SM", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body); 
                    auth['sm'] = res.token;
                    expect(res.token).to.not.equal(null);
                    expect(resp.statusCode).to.equals(200);
                    done();
                }
            });
        });
        it('Test User Authentication for Lab Technician.', function (done) {
            logHelper.logMethodEntry(logger, 'UserAuthentication', configData.BASE_URL + "user/authenticate");
            var jsonData = {
                userId: configData.auth.LT.userId,
                password: configData.auth.LT.password,
                subscriptionKey: configData.SUB_KEY
            };
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"]
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/authenticate", method: constants.REQUEST_POST, headers: headers, body: JSON.stringify(jsonData)}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'User Authentication', "authenticate LT", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body); 
                    auth['lt'] = res.token;
                    expect(res.token).to.not.equal(null);
                    expect(resp.statusCode).to.equals(200);
                    done();
                }
            });
        });
        it('Test User Authentication for Judiciary.', function (done) {
            logHelper.logMethodEntry(logger, 'UserAuthentication', configData.BASE_URL + "user/authenticate");
            var jsonData = {
                userId: configData.auth.JA.userId,
                password: configData.auth.JA.password,
                subscriptionKey: configData.SUB_KEY
            };
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"]
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/authenticate", method: constants.REQUEST_POST, headers: headers, body: JSON.stringify(jsonData)}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'User Authentication', "authenticate Judiciary", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body); 
                    auth['ja'] = res.token;
                    expect(res.token).to.not.equal(null);
                    expect(resp.statusCode).to.equals(200);
                    done();
                }
            });
        });
        it('Test User Authentication for Auditor.', function (done) {
            logHelper.logMethodEntry(logger, 'UserAuthentication', configData.BASE_URL + "user/authenticate");
            var jsonData = {
                userId: configData.auth.A.userId,
                password: configData.auth.A.password,
                subscriptionKey: configData.SUB_KEY
            };
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"]
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/authenticate", method: constants.REQUEST_POST, headers: headers, body: JSON.stringify(jsonData)}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'User Authentication', "authenticate Auditor", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body); 
                    auth['a'] = res.token;
                    expect(res.token).to.not.equal(null);
                    expect(resp.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Success Scenario for find user by Persona
    */
    describe("Test Find find user by Persona, Success Scenario", function () {
        it('Find find user by Persona', function (done) {
            logHelper.logMethodEntry(logger, 'findByPersona', configData.BASE_URL + "user/findByPersona");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/findByPersona?persona=Field_Agent", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'findByPersona', "find user by Persona", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Failure Scenario for find user by Persona
    */
    describe("Test Find find user by Persona, Failure Scenario", function () {
        it('Find find user by Persona', function (done) {
            logHelper.logMethodEntry(logger, 'findByPersona', configData.BASE_URL + "user/findByPersona");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/findByPersona?persona=Field_Agent123", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'findByPersona', "find user by Persona", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(204);
                    done();
                }
            });
        });
    });

    /**
     * Success Scenario for find user by userId
    */
    describe("Test Find find user by user Id, Success Scenario", function () {
        it('Find find user by userId', function (done) {
            logHelper.logMethodEntry(logger, 'findByUserId', configData.BASE_URL + "user/findByUserId");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/findByUserId?userId="+configData.auth.FA.userId, method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'findByUserId', "find user userId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Failure Scenario for find user by userId
    */
    describe("Test Find find user by userId, Failure Scenario", function () {
        it('Find find user by userId', function (done) {
            logHelper.logMethodEntry(logger, 'findByUserId', configData.BASE_URL + "user/findByUserId");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "user/findByUserId?userId=xyz@abc.com", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'findByUserId', "find user by userId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(204);
                    done();
                }
            });
        });
    });

    /**
     * Test Add Case
    */
    describe("Test Add Case", function () {
        for(var i = 0; i < configData.cases.length; i++) {
            it('Adding Case: '+i, function (done) {   
                logHelper.logMethodEntry(logger, 'addCase '+itrCase, configData.BASE_URL + "case");
                var reqBody = JSON.stringify(configData.cases[itrCase]);
                var headers = {
                    "Content-Type": constants["CONTENT-TYPE"],
                    "token": auth.fa
                };
                this.timeout(60000);
                request({url: configData.BASE_URL + "case", method: constants.REQUEST_POST, headers: headers, body: reqBody}, function(error, resp, body){
                    itrCase=itrCase+1;
                    if(error) {
                        logHelper.logDebug(logger, 'addCase', "add case "+ i, "Error :", error);
                    } else {
                        var res = JSON.parse(resp.body);
                        if(res.success) {
                            caseIds.push(res.result.caseId);
                            expect(res.result.caseId).to.not.equal(null);
                            expect(res.statusCode).to.equals(200);
                            done();
                        }
                    }
                });
            });
        }
    });
    /**
     * Test Add Evidence
    */
    describe("Test Add Evidences", function () { 
        for(var i = 0; i < configData.evidences.length; i++) {
            it('Adding Evidence :'+i, function (done) {   
                logHelper.logMethodEntry(logger, 'addEvidence', configData.BASE_URL + "evidence");
                var jsonBody = configData.evidences[itrEvidence];
                jsonBody['caseId'] = caseIds[itrEvidence];
                var reqBody = JSON.stringify(jsonBody);
                var headers = {
                    "Content-Type": constants["CONTENT-TYPE"],
                    "token": auth.fa
                };
                this.timeout(120000);
                request({url: configData.BASE_URL + "evidence", method: constants.REQUEST_POST, headers: headers, body: reqBody}, function(error, resp, body){
                itrEvidence = itrEvidence+1;
                    if(error) {
                        logHelper.logDebug(logger, 'addEvidence', "add Evidence", "Error :", error);
                    } else {
                        var res = JSON.parse(resp.body);
                        if(res.success) {
                            evidenceIds.push(res.result.evidenceId);
                            expect(res.result.evidenceId).to.not.equal(null);
                            expect(res.statusCode).to.equals(200);
                            done();
                        }
                    }
                });
            });
        }
    });

    /**
     * Test Add State
    */
    describe("Test State", function () { 
        for(var i = 0; i < configData.states.length; i++) {
            it('Adding State :' +i, function (done) {   
                logHelper.logMethodEntry(logger, 'addState', configData.BASE_URL + "state");
                var jsonBody = configData.states[itrState];
                    jsonBody['evidenceId'] = evidenceIds[itrState];
                    var reqBody = JSON.stringify(jsonBody);
                var headers = {
                    "Content-Type": constants["CONTENT-TYPE"],
                    "token": auth.fa
                };
                this.timeout(200000);
                request({url: configData.BASE_URL + "state", method: constants.REQUEST_POST, headers: headers, body: reqBody}, function(error, resp, body){
                    itrState = itrState+1;
                    if(error) {
                        logHelper.logDebug(logger, 'addState', "add State", "Error :", error);
                    } else {
                        var res = JSON.parse(resp.body);
                        if(res.success) {
                            stateId = res.result.stateId;
                            expect(res.statusCode).to.equals(200);
                            done();
                        }
                    }
                });
            });
        }
    });

    /**
    * Success Scenario for find Case By CaseId
    */
    describe("Find Case By CaseId, Success Scenario", function () {
        it('Find Case By CaseId', function (done) {
            logHelper.logMethodEntry(logger, 'findByCaseId', configData.BASE_URL + "case/findByCase/");
            
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "case/findByCase/"+caseIds[0], method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'findByCaseId', "find case by caseId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Failure Scenario for find Case By CaseId
    */
    describe("Find Case By CaseId, Failure Scenario", function () {
        it('Find Case By CaseId', function (done) {
            logHelper.logMethodEntry(logger, 'findByCaseId', configData.BASE_URL + "case/findByCase/");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "case/findByCase/1111", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'findByCaseId', "find case by caseId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(204);
                    done();
                }
            });
        });
    });

    /**
     * For Find all Cases
    */
    describe("Find all Case", function () {
        it('Find all Case', function (done) {
            logHelper.logMethodEntry(logger, 'findAll', configData.BASE_URL + "case/findAll");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "case/findAll", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'findAll', "find all cases", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Success Scenario for find Evidence By evidenceId
    */
    describe("Test Find Evidence By evidenceId, Success Scenario", function () {
        it('Find Evidence By evidenceId', function (done) {
            logHelper.logMethodEntry(logger, 'getEvidenceById', configData.BASE_URL + "evidence");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "evidence/"+evidenceIds[0], method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'getEvidenceById', "Find Evidence By evidenceId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Failure Scenario for find Evidence By evidenceId
    */
    describe("Test Find Evidence By evidenceId, Failure Scenario", function () {
        it('Find Evidence By evidenceId', function (done) {
            logHelper.logMethodEntry(logger, 'getEvidenceById', configData.BASE_URL + "evidence");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "evidence/"+"212", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'getEvidenceById', "Find Evidence By evidenceId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(204);
                    done();
                }
            });
        });
    });

    /**
     * Success Scenario for find Evidence By caseId
    */
    describe("Test Find Evidence By CaseId, Success Scenario", function () {
        it('Find Evidence By caseId', function (done) {
            logHelper.logMethodEntry(logger, 'getEvidenceByCaseId', configData.BASE_URL + "evidence/findByCaseId/");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "evidence/findByCaseId/"+caseIds[0], method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'getEvidenceByCaseId', "Find Evidence By CaseId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Failure Scenario for find Evidence By caseId
    */
    describe("Test Find Evidence By CaseId, Failure Scenario", function () {
        it('Find Evidence By caseId', function (done) {
            logHelper.logMethodEntry(logger, 'getEvidenceByCaseId', configData.BASE_URL + "evidence/findByCaseId/");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "evidence/findByCaseId/"+"121", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'getEvidenceByCaseId', "Find Evidence By CaseId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(204);
                    done();
                }
            });
        });
    });

    /**
     * Find all Evidence
    */
    describe("Test Find all evidences", function () {
        it('Test Find all evidences', function (done) {
            logHelper.logMethodEntry(logger, 'findAllEvidences', configData.BASE_URL + "evidence/findAll");
            
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "evidence/findAll", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'findAllEvidences', "Find all Evidence", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Success Scenario for find state By stateId
    */
    describe("Test Find state By stateId, Success Scenario", function () {
        it('Find state By stateId', function (done) {
            logHelper.logMethodEntry(logger, 'getStateById', configData.BASE_URL + "state");
            
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "state/"+stateId, method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'getStateById', "state By stateId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Failure Scenario for find state By stateId
    */
    describe("Test Find state By stateId, Failure Scenario", function () {
        it('Find state By stateId', function (done) {
            logHelper.logMethodEntry(logger, 'getStateById', configData.BASE_URL + "state");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "state/"+"111", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'getStateById', "state By stateId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(204);
                    done();
                }
            });
        });
    });

    /**
     * Success Scenario for find state By evidenceId
    */
    describe("Test Find state By evidenceId, Success Scenario", function () {
        it('Find state By evidenceId', function (done) {
            logHelper.logMethodEntry(logger, 'getStateByEvidenceId', configData.BASE_URL + "state/findByEvidence");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "state/findByEvidence/"+evidenceIds[0], method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'getStateByEvidenceId', "state By evidenceId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(200);
                    done();
                }
            });
        });
    });

    /**
     * Failure Scenario for find state By evidenceId
    */
    describe("Test Find state By evidenceId, Failure Scenario", function () {
        it('Find state By evidenceId', function (done) {
            logHelper.logMethodEntry(logger, 'getStateByEvidenceId', configData.BASE_URL + "state/findByEvidence");
            var headers = {
                "Content-Type": constants["CONTENT-TYPE"],
                "token": auth.fa
            };
            this.timeout(60000);
            request({url: configData.BASE_URL + "state/findByEvidence/"+"1211", method: constants.REQUEST_GET, headers: headers}, function(error, resp, body){
                if(error) {
                    logHelper.logDebug(logger, 'getStateByEvidenceId', "state By evidenceId", "Error :", error);
                } else {
                    var res = JSON.parse(resp.body);
                    expect(res.statusCode).to.equals(204);
                    done();
                }
            });
        });
    });
});