﻿'use strict';

var Client = require('node-rest-client').Client;
var config = require('config');
var client = new Client();
var fs = require('fs');
var configDetails = fs.readFileSync('config/config.json', 'utf8');
var configData = JSON.parse(configDetails);
var request = require('async-request');
var request2 = require('request-promise');
var constants = require('../config/constants.js');
var logHelper = require('../utils/logging.js');
var logger = logHelper.getLogger(config.processname);

module.exports = {
    enrollUser: enrollUser,
    invokeChainCode: invokeChainCode,
    queryChainCode: queryChainCode,
    listChannelInfo: listChannelInfo,
    queryBlockByTransactionId: queryBlockByTransactionId,
    MakePDF: MakePDF,
    downloadFile: downloadFile,
    queryStatusByEnvlopeId: queryStatusByEnvlopeId,
    sendEmail: sendEmail
}

/**
 * This method is used to enroll the user.
 * @param {*} userId 
 */
async function enrollUser(userId) {
  logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.ENROLL_USER);
    var response;
    try {
        var bodyParam = {
            username: userId,
            orgName: constants.ORG_NAME
        };
        var response = await request(configData.ENROLL_USER_SERVICE_URL, {
            method: constants.REQUEST_POST,
            data: bodyParam,
            headers: {
                "Content-Type": constants["CONTENT-TYPE"]
            },
        });
    }
    catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.ENROLL_USER, error);
        return error;
    }
    logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.ENROLL_USER, constants.RESPONSE, response);
    logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.ENROLL_USER);
    return response;
}

/**
 * This method is used to invoke the data
 * @param {*} fabricToken 
 * @param {*} reqBodyData 
 * @param {*} chainName 
 * @param {*} functionname 
 */
async function invokeChainCode(fabricToken, reqBodyData, chainName, functionname) {
    logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE);
    console.log("reqBodyData---", reqBodyData);
    console.log("chainName---", chainName);
    console.log("functionname---", functionname);

    try {
        var url = configData.CHAINCODE_API_SERVICE_URL + configData.channelName + "/chaincodes/" + chainName;
        var options = {
            method:  constants.REQUEST_POST,
            uri: url,
            body: {
                peers: [configData.chaincodes.peers.peer0, configData.chaincodes.peers.peer1],
                fcn: functionname,
                args: [reqBodyData]
            },
            headers: {
                "Content-Type": constants["CONTENT-TYPE"],
                "authorization": "Bearer " + fabricToken
            },
            json: true
        };
        try {
         var response = await request2(options);
         logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, constants.RESPONSE, response);
         logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE);
         return Promise.resolve(response);
        } catch (error) {
            logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, error);
            Promise.reject(error);
        }
    } catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, error);
        return error;
    }
}
/**
 * This method is used to invoke the data
 * @param {*} fabricToken 
 * @param {*} reqBodyData 
 * @param {*} chainName 
 * @param {*} functionname 
 */
async function MakePDF(reqBodyData) {
    logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE);
    var body1 = JSON.stringify(reqBodyData);

    console.log("reqBodyDataupdate---", body1);
    var body = JSON.parse(body1);

    try {
        var url = configData.PDF_API_URL;
        var options = {
            method: constants.REQUEST_POST,
            uri: url,
           body,
            headers: {
                "Content-Type": constants["CONTENT-TYPE"]
               
            },
            json: true
        };
        try {
            console.log("----PDF IMAGE --------------------------------------------", options)
            var response = await request2(options);
            logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, constants.RESPONSE, response);
            logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE);
            return Promise.resolve(response);
        } catch (error) {
            logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, error);
            Promise.reject(error);
        }
    } catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, error);
        return error;
    }
}


async function downloadFile(fileName) {
    logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE);
    try {
        var mimetype = mime.lookup(filename);
       
        var url = configData.DOWNLOAD_API_URL + "/" + fileName
      
        console.log("file download url******&&&", url)
        var options = {
            method: constants.REQUEST_GET,
            uri: url,
            headers: {
                "Content-Type": mimetype,
                
            },
         
        };

        try {
            var response = await request2(options);
            logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE, constants.RESPONSE, response);
            logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE);
            return Promise.resolve(response);
        }
        catch (error) {
            logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE, error);
            Promise.reject(error);
        }
    } catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE, error);
        return error;
    }
}
/**
 * This method is used to query the data
 * @param {*} fabricToken 
 * @param {*} Id 
 * @param {*} chainCodeName 
 * @param {*} functionname 
 */
async function queryChainCode(fabricToken, Id, chainCodeName, functionname) {
    logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE);
    try {
        if(Id != ""){
            var url = configData.CHAINCODE_API_SERVICE_URL + configData.channelName + "/chaincodes/" + chainCodeName + "?peer=" + configData.chaincodes.peers.peer0 + "&fcn=" + functionname + "&args=%5B%22"+Id+"%22%5D"; 
        } else {
            var url = configData.CHAINCODE_API_SERVICE_URL + configData.channelName + "/chaincodes/" + chainCodeName + "?peer=" + configData.chaincodes.peers.peer0 + "&fcn=" + functionname + "&args=%5B%22%22%5D"; 
        }
        console.log("url________******&&&",url)
        var options = {
            method:  constants.REQUEST_GET,
            uri: url,
            headers: {
                "Content-Type": constants["CONTENT-TYPE"],
                "authorization": "Bearer " + fabricToken
            },
            json: true
        };
        
        try {
            var response = await request2(options);
            logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE, constants.RESPONSE, response);
            logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE);
            return Promise.resolve(response);
           }
           catch (error) {
            logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE, error);
            Promise.reject(error);
           }
    } catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_CHAINCODE, error);
        return error;
    }
}

/**
 * This method is used to get the block by transaction Id
 * @param {*} fabricToken 
 * @param {*} transactionId 
 */
async function queryBlockByTransactionId(fabricToken, transactionId){
    logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID);
    try {
        var url = configData.CHAINCODE_API_SERVICE_URL +configData.channelName+ "/block/" +transactionId+ "?peer="+configData.chaincodes.peers.peer0; 
        var options = {
            method:  constants.REQUEST_GET,
            uri: url,
            headers: {
                "Content-Type": constants["CONTENT-TYPE"],
                "authorization": "Bearer " + fabricToken
            },
            json: true
        };
        try {
            var response = await request2(options);
            logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID, constants.RESPONSE, response);
            logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID);
            return Promise.resolve(response);
           }
           catch (error) {
                logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID, error);
               Promise.reject(error);
           }
    }
    catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID, error);
        return error;
    }  
}

/**
 * This method is used to get the channel info
 * @param {*} fabricToken 
 */
async function listChannelInfo(fabricToken) {
    logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.LIST_CHANNEL_INFO);
    try {
        var url = configData.CHAINCODE_API_SERVICE_URL + configData.channelName + "?peer=" + configData.chaincodes.peers.peer0;
        var options = {
            method:  constants.REQUEST_GET,
            uri: url,
            headers: {
                "Content-Type": constants["CONTENT-TYPE"],
                "authorization": "Bearer " + fabricToken
            },
            json: true
        };
        try {
            var response = await request2(options);
            logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.LIST_CHANNEL_INFO, constants.RESPONSE, response);
                return Promise.resolve(response);
           }
           catch (error) {
            logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.LIST_CHANNEL_INFO, error);
               Promise.reject(error);
           }
    }catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.LIST_CHANNEL_INFO, error);
        return error;
    }
    logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.LIST_CHANNEL_INFO);
}


async function queryStatusByEnvlopeId(envlopeId) {
    logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID);
    try {
        var url = configData.GET_STATUS_FROM_DOCUSIGN_API_URL + "?envelopeID=" + envlopeId ;
        var options = {
            method: constants.REQUEST_GET,
            uri: url,
            headers: {
                "Content-Type": constants["CONTENT-TYPE"]
                
            },
            json: true
        };
        try {
            var response = await request2(options);
            logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID, constants.RESPONSE, response);
            logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID);
            return Promise.resolve(response);
        }
        catch (error) {
            logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID, error);
            Promise.reject(error);
        }
    }
    catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.QUERY_BLOCK_BY_TRANSACTION_ID, error);
        return error;
    }
}

async function sendEmail(reqBodyData) {
    logHelper.logMethodEntry(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE);
    var body1 = JSON.stringify(reqBodyData);

    console.log("reqBodyDataupdate---", body1);
    var body = JSON.parse(body1);

    try {
        var url = configData.SEND_MAIL_API;
        var options = {
            method: constants.REQUEST_POST,
            uri: url,
            body,
            headers: {
                "Content-Type": constants["CONTENT-TYPE"]

            },
            json: true
        };
        try {
            console.log("----PDF IMAGE --------------------------------------------", options)
            var response = await request2(options);
            logHelper.logDebug(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, constants.RESPONSE, response);
            logHelper.logMethodExit(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE);
            return Promise.resolve(response);
        } catch (error) {
            logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, error);
            Promise.reject(error);
        }
    } catch (error) {
        logHelper.logError(logger, constants.CHAINCODE_SERVICE_FILE, constants.INVOKE_CHAINCODE, error);
        return error;
    }
}