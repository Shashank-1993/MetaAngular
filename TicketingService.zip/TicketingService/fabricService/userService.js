'use strict';
const auth = require('../api/helpers/auth');
var chaincodeService = require('../service/chaincodeService');
var constants = require('../config/constants.js');
var config = require('config');
var logHelper = require('../utils/logging.js');
var logger = logHelper.getLogger(config.processname);
var db = require('../api/helpers/CouchDBCommon.js');
var crypto = require('crypto');

module.exports = {
    authenticateUser: authenticateUser,
    authenticateUserExist: authenticateUserExist,
    enrollUser, enrollUser,
  validateToken: validateToken,
  findByUserId: findByUserId,
  findByPersona: findByPersona,
  findAllUser:findAllUser
}

/**
 * This method is used to authenticate the user
 * @param {*} userpassworddetails 
 * @param {*} res 
 */
async function authenticateUser(userpassworddetails, res) {
  logHelper.logMethodEntry(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER);
  logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, constants.REQUEST, userpassworddetails);
  var userpassworddetails;
  var result = {};
  try {
    var tokenDetails = await auth.generateToken(userpassworddetails, res);
    result = {
      userId: userpassworddetails.userName,
      persona: tokenDetails.persona,
      name: tokenDetails.name,
      token: tokenDetails.token,
      message: tokenDetails.message,
      fabricToken: tokenDetails.fabricToken,
      branchName: tokenDetails.branchName,
      companyAddress:tokenDetails.companyAddress,
      aNumber:tokenDetails.aNumber,
      code: tokenDetails.code
    }
    if (Object.keys(result).length > 0) {
      logHelper.logMethodExit(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER);
      logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, constants.RESPONSE, result);
      return result;
    }
  }catch (error) {
    logHelper.logError(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, error);
    return ({code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500});
  }
}

/**
 * This method is used to authenticate the user
 * @param {*} userpassworddetails 
 * @param {*} res 
 */
async function authenticateUserExist(userId, res) {
    logHelper.logMethodEntry(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER);
    logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, constants.REQUEST, userpassworddetails);
   
    var result = {};
    try {
        console.log("userpassworddetails.userId--->", userId)
        var result = await db.find({ "userId": userId });
        console.log("---result---", result);
            result = {
                userId: result[0].userName

            }
      
        if (Object.keys(result).length > 0) {
            logHelper.logMethodExit(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER);
            logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, constants.RESPONSE, result);
            return result;
        }
    } catch (error) {
        logHelper.logError(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, error);
        return ({ code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500 });
    }
}

/**
 * This method is used to authenticate the user
 * @param {*} userpassworddetails 
 * @param {*} res 
 */




async function enrollUser(userpassworddetails, res) {
    console.log("----inside Sevice-----");
    console.log("---userpassworddetails---", userpassworddetails);
    logHelper.logMethodEntry(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER);
    logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, constants.REQUEST, userpassworddetails);
    var userpassworddetails;
    var hashpassword = crypto.createHash('sha256').update(userpassworddetails.password).digest('hex');
    var result = {};
    try {
              result = {
                  userId: userpassworddetails.userId,
                  password: hashpassword,
                  persona:userpassworddetails.persona,
                  userName: userpassworddetails.userName,
                  companyRegistrationNumber:userpassworddetails.companyRegistrationNumber,
                  companyAddress:userpassworddetails.companyAddress,
                  aNumber:userpassworddetails.aNumber,
                  branchName:userpassworddetails.branchName,
                  activeStatus: '1'
        }
        console.log("result-----$$", result);
        var result = await db.save(result);
        if (Object.keys(result).length > 0) {
            logHelper.logMethodExit(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER);
            logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, constants.RESPONSE, result);
            return result;
        }
    } catch (error) {
        logHelper.logError(logger, constants.USER_SERVICE_FILE, constants.AUTHENTICATE_USER, error);
        return ({ code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500 });
    }
}



/**
 * This method is used to validate the token
 * @param {*} token 
 */
function validateToken(token) {
  logHelper.logMethodEntry(logger, constants.USER_SERVICE_FILE, constants.VALIDATE_TOKEN);
  logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.VALIDATE_TOKEN, constants.REQUEST, token);
  return new Promise(function (resolve, reject) {
    auth.validateToken(token, function (response) {
      if (response && response.code) {
        var result = {};
        result['application/json'] = {
          "code": response.code,
          "message": response.message,
          "decodedToken": response.decodedToken,
          "success": (response.code === constants.SUCCESS ? constants.TRUE : constants.FALSE)
        }
        logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.VALIDATE_TOKEN, constants.RESPONSE, result);
        logHelper.logMethodExit(logger, constants.USER_SERVICE_FILE, constants.VALIDATE_TOKEN);
        resolve(result[Object.keys(result)[0]]);
      }
    });
  }).catch(function (error) {
    logHelper.logError(logger, constants.USER_SERVICE_FILE, constants.VALIDATE_TOKEN, error);
    return resolve({ code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500});
  });
}

/**
 * This method is used to find user by the userid
 * @param {*} userId 
 */
async function findByUserId(userId) {
  logHelper.logMethodEntry(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_USER_ID);
  logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_USER_ID, constants.REQUEST +"UserId - "+ userId);
  try{
    var result = await db.find({"userId": userId.toString()}); 
    var res = [];
      if (result.length > 0) {
        logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_USER_ID, constants.RESPONSE, result);
        logHelper.logMethodExit(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_USER_ID);
        return ({statusCode:constants.SUCCESS, result:result});
      } else {
        return ({statusCode:constants.NO_CONTENT, result:res});
      } 
  } catch(error){
    logHelper.logError(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_USER_ID, error);
    return ({code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500});
  }
}

/**
 * This method is used to find user by the persona
 * @param {*} persona 
 */
async function findByPersona(persona) {
  logHelper.logMethodEntry(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_PERSONA);
  logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_PERSONA, constants.REQUEST +"Persona - "+ persona);
  try{
    var result = await db.find({"persona": persona.toString()}); 
    var res = [];
      if (result.length > 0) {
        logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_PERSONA, constants.RESPONSE, result);
        logHelper.logMethodExit(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_PERSONA);
        return ({statusCode:constants.SUCCESS, result:result});
      } else {
        return ({statusCode:constants.NO_CONTENT, result:res});
      } 
  } catch(error){
    logHelper.logError(logger, constants.USER_SERVICE_FILE, constants.FIND_BY_PERSONA, error);
    return ({code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500});
  }
}
async function findAllUser()   {
  logHelper.logMethodEntry(logger, constants.USER_SERVICE_FILE, constants.FIND_ALL_USER);
  logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.FIND_ALL_USER);
  try{
    var result = await db.find({"activeStatus": '1'}); 
      var resp = [];
      if (result.length > 0) {
          for (var i = 0; i < result.length; i++) {
              resp.push(result[i]);
          }
        logHelper.logDebug(logger, constants.USER_SERVICE_FILE, constants.FIND_ALL_USER, constants.RESPONSE, result);
        logHelper.logMethodExit(logger, constants.USER_SERVICE_FILE, constants.FIND_ALL_USER);
          return ({ statusCode: constants.SUCCESS, result: resp });
      } else {
        return res;
      } 
  } catch(error){
    logHelper.logError(logger, constants.USER_SERVICE_FILE, constants.FIND_ALL_USER, error);
    return ({code: constants.INTERNAL_SERVER_ERROR, message: constants.MESSAGE_500});
  }
}