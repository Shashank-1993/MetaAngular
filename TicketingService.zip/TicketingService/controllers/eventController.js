'use strict';

var utils = require('../utils/writer.js');
var eventService = require('../service/eventService');
var config = require('config');
var constants = require('../config/constants.js');
var logHelper = require('../utils/logging.js');
var logger = logHelper.getLogger(config.processname);

module.exports = {
 
  createEvent:createEvent,
  getAllEvent:getAllEvent
}


/**
 * This method will register Property by lessor.
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
 function createEvent1(req, res, next) {
  logHelper.logMethodEntry(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY);
    logHelper.logDebug(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY, constants.REQUEST);
  logHelper.logDebug(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY, constants.REQUEST);
  console.log("inside service=============",req.body.eventdetails);
  eventService.createEvent(req, req.body.eventdetails).then(function (response) {
    logHelper.logDebug(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY, constants.RESPONSE, response);
    logHelper.logMethodExit(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY);
      utils.writeJson(res, response,constants.SUCCESS);
    }).catch(function (response) {
      utils.writeJson(res, response,constants.ERROR_CODE);
    });
};

function createEvent(req, res, next) {
  console.log("hiiii------")
  logHelper.logMethodEntry(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY);
    logHelper.logDebug(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY, constants.REQUEST, req.body);
  logHelper.logDebug(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY, constants.REQUEST );
  eventService.createEvent(req,req.body).then(function (response) {
    logHelper.logDebug(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY, constants.RESPONSE, response);
    logHelper.logMethodExit(logger, constants.LESSOR_CONTROLLER_FILE, constants.REGISTER_PROPERTY);
      utils.writeJson(res, response,constants.SUCCESS);
    }).catch(function (response) {
      utils.writeJson(res, response,constants.ERROR_CODE);
    });
};

function getAllEvent(req, res, next) {
  logHelper.logMethodEntry(logger, constants.TRANSACTION_CONTROLLER_FILE, constants.GET_TRANSACTION_BY_PARENT_ID);
   
    logHelper.logDebug(logger, constants.TRANSACTION_CONTROLLER_FILE, constants.GET_TRANSACTION_BY_PARENT_ID, constants.REQUEST );
    eventService.getAllEvent().then(function (response) {
      logHelper.logDebug(logger, constants.TRANSACTION_CONTROLLER_FILE, constants.GET_TRANSACTION_BY_PARENT_ID, constants.RESPONSE, response);
      logHelper.logMethodExit(logger, constants.TRANSACTION_CONTROLLER_FILE, constants.GET_TRANSACTION_BY_PARENT_ID);
      utils.writeJson(res, response, constants.SUCCESS);
    }).catch(function (response) {
      utils.writeJson(res, response, constants.ERROR_CODE);
    });
}



