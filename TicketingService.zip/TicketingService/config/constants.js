'use strict';

/**
@author:Vikas Sharma
@version: 1.0
@date: 21/08/2018
@Description: constants file
**/

module.exports = {
    //use key for Token Generation
	"TRANSACTION_ID": "TransactionId",
	"EVENT_ID":"eventId",
	"SHARED_SECRET": "shh",
	"ISSUER": "standardbank.co.za",
	//Http codes
	"SUCCESS": 200,
	"UNAUTHORIZED": 401,
	"NOT_FOUND": 404,
	"FORBIDDEN": 403,
	//"METHOD_NOT_ALLOWED": 405,
	"SIGNATURE_FAILURE": 406,
	"UNSUPPORTED_MEDIA_TYPE": 415,
	"NO_CONTENT": 204,
	"INVALID_INPUT": 400,
	"ERROR_CODE": 405,
	"TRUE": "true",
	"FALSE": "false",
	"TOKEN_ERROR": "Invalid credential so token is not created",
	"CONNECTION_ERROR": "connection error",
	"INTERNAL_SERVER_ERROR": 500,
	"CONTENT-TYPE": "application/json",
	
	"RESPONSE": "Response :",
	"REQUEST": "Request :",


	//Messages for http methods
	"MESSAGE_400": "Bad Request - The request couldn’t be understood, usually because the JSON body contains an error.",
	"MESSAGE_401": "Invalid Authentication - The Authentication token used has expired or is invalid. The response body contains the message and errorCode.",
	"MESSAGE_403": "Forbidden - The request has been refused. Verify that the logged-in user has appropriate permissions.",
	"MESSAGE_404":	"Not Found - The requested resource couldn’t be found. Check the URI for errors, and verify that there are no sharing issues.",
	"MESSAGE_405":	"Method Not Allowed - The method specified in the Request-Line isn’t allowed for the resource specified in the URI.",
	"MESSAGE_406":	"Signature Failure - The Token/Signature is invalid or The timestamp is stale.",
	"MESSAGE_415":	"Unsupported Media Type - The entity in the request is in a format that’s not supported by the specified method.",
	"MESSAGE_422":	"Unprocessable Entity - The request parameters did not passed validation specification.",
	"MESSAGE_429":	"Too Many Requests - The request is rejected due to rate limiting.",
	"MESSAGE_500":	"Server Error - An error has occurred within Service API, so the request couldn’t be completed.",
	"INVALID_PARAM": "Input params are invalid.",
	"MESSAGE_204": "No Content - Data doesn't exist in the repository",
	"WRONG_SUB_KEY": "User authentication failed as wrong subscription key provided.",
	"INPUT_TOKEN": "Error: Token is invalid.",
	"VALID_TOKEN": "Token is valid.",
	"DATA_NOT_ADDED": "could not add data.",
	"TRANSACTION_NOT_ADDED": "Tranaction data not added.",
	"LESSOR_CONTROLLER_FILE": "lessorControllerFile",
	"LESSOR_SERVICE_FILE":"lessorServiceFile",
	"RENTER_CONTROLLER_FILE":"renterControllerFile",
	"RENTER_SERVICE_FILE":"renterServiceFile",
	"FIND_PROPERTY_BY_PROPERTYID":"findPropertyByPropertyId",
	"LIST_PROPERTY":"listProperty",
	"BOOK_MEETING":"bookMeeting",
	"FIND_PROPERTY_BY_MEETINGID":"findPropertyByMeetingId",
	"FIND_ALL_PROPERTY":"findAllProperty",
	
	
	"REGISTER_PROPERTY": "registerProperty",
	"REGISTER_PROPERTY_BY_LESSOR": "registerPropertyByLessor",

	"CHAINCODE_SERVICE_FILE": "chaincodeService",
	"AUTH_FILE": "auth",
	"TRANSACTION_CONTROLLER_FILE": "transactionController",
	"TRANSACTION_SERVICE_FILE": "transactionService",
	"USER_CONTROLLER_FILE": "userController",
	"USER_SERVICE_FILE": "userService",

	
		"ENROLL_USER": "enrollUser",
    "INVOKE_CHAINCODE": "invokeChainCode",
    "QUERY_CHAINCODE": "queryChainCode",
    "LIST_CHANNEL_INFO": "listChannelInfo",
	"QUERY_BLOCK_BY_TRANSACTION_ID": "queryBlockByTransactionId",
	"ADD_BUYER": "addBuyerDetailsAndRemarks",
	"DOWNLOAD_FILE": "download File",
		"VALIDATE_TOKEN": "validateToken",
	"GENERATE_TOKEN": "generateToken",
	"GET_DETAILS_BY_TRANSACTION_ID": "getTransactionByTransactionId",
	"GET_TRANSACTION_BY_EVIDENCE_ID": "getTransactionByEvidenceId",
	"GET_BLOCK_BY_EVIDENCE_ID": "getBlockByEvidenceId",
	"GET_TRANSACTION_BY_PARENT_ID": "getTransactionsByParentId",
	"GET_CURRENT_BLOCK": "getCurrentBlock",
	"ADD_TRANSACTION": "addTransaction",
	"GET_TRANSACTION_BY_ASSET_ID": "getTransactionsByAssetId",
	"AUTHENTICATE_USER": "authenticateUser",
	"VALIDATE_TOKEN_INTERNALLY": "validateTokenInternally",
	"VALIDATE_TOKEN":"validateToken",
	"FIND_BY_USER_ID":"findByUserId",
	"FIND_BY_PERSONA":"findByPersona",
	"REQUEST_POST": "POST",
	"REQUEST_GET": "GET",
	"ORG_NAME": "Org1",
	
}