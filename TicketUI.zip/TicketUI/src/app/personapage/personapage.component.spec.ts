import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonapageComponent } from './personapage.component';

describe('PersonapageComponent', () => {
  let component: PersonapageComponent;
  let fixture: ComponentFixture<PersonapageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonapageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonapageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('set theme based on persona Field_Agent', () => {
    expect(component.setTheme('Field_Agent')).toContain('fa-theme');
  });

  it('set theme based on persona Storage_Agent', () => {
    expect(component.setTheme('Storage_Agent')).toContain('sm-theme');
  });

  it('set theme based on persona Auditor', () => {
    expect(component.setTheme('Auditor')).toContain('auditor-theme');
  });

  it('set theme based on persona Lab_Tech', () => {
    expect(component.setTheme('Lab_Tech')).toContain('lab-tech-theme');
  });

  it('set theme based on persona Judicial_Agent', () => {
    expect(component.setTheme('Judicial_Agent')).toContain('judge-theme');
  });

});
