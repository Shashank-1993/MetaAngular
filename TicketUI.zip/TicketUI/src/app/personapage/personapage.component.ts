import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ThemeService } from '../service/theme/theme.service';
import { DEFAULT_THEME, JWT_TOKEN_KEY, THEME_KEY } from '../app.constant';

@Component({
  selector: 'irm-personapage',
  templateUrl: './personapage.component.html',
  styleUrls: ['./personapage.component.scss']
})
export class PersonapageComponent implements OnInit {
  @Output()
  themeApplied: EventEmitter<boolean> = new EventEmitter();
  @Output()
  currentPersona: EventEmitter<string> = new EventEmitter();
  constructor(private themeService: ThemeService) {}

  /**
   *
   * Initializing theme.
   * @memberof PersonapageComponent
   */
  ngOnInit() {
    sessionStorage.setItem(THEME_KEY, DEFAULT_THEME);
    this.themeService.theme.next(DEFAULT_THEME);
  }

  /**
   *
   * Setting seleted theme.
   * @param {string} type
   * @memberof PersonapageComponent
   */
  setTheme(type: string) {
    let theme;
    switch (type) {
      case 'Agent':
        theme = 'fa-theme';
        break;
      case 'Seller':
        theme = 'sm-theme';
        break;
      case 'Auditor':
        theme = 'auditor-theme';
        break;
      case 'Buyer':
        theme = 'lab-tech-theme';
        break;
      case 'Judicial_Agent':
        theme = 'judge-theme';
        break;
      default:
        theme = 'default-theme';
        break;
    }
    sessionStorage.removeItem(THEME_KEY);
    sessionStorage.setItem(THEME_KEY, theme);
    this.themeService.theme.next(theme);
    this.themeApplied.emit(true);
    this.currentPersona.emit(type);
  }

}
