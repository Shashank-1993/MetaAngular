import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SnackbarRecievedComponent } from './snackbar-recieved.component';

describe('SnackbarRecievedComponent', () => {
  let component: SnackbarRecievedComponent;
  let fixture: ComponentFixture<SnackbarRecievedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SnackbarRecievedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SnackbarRecievedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
