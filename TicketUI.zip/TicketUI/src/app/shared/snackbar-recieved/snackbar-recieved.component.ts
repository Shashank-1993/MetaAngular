import { Component, OnInit, Inject } from '@angular/core';
import { MAT_SNACK_BAR_DATA } from '@angular/material';

@Component({
  selector: 'irm-snackbar-recieved',
  templateUrl: './snackbar-recieved.component.html',
  styleUrls: ['./snackbar-recieved.component.scss']
})
export class SnackbarRecievedComponent {
  public snakbarRecievedComponentRef: any;
  constructor(@Inject(MAT_SNACK_BAR_DATA) public data: any) { }

  closeSnakBar() {
    this.snakbarRecievedComponentRef.dismiss();
  }
}
