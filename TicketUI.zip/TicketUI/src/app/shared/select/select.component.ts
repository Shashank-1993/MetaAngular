import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { OverlayContainer } from '@angular/cdk/overlay';
import { ThemeService } from '../../service/theme/theme.service';
import { SelectboxService } from '../../service/selectbox-clear/selectbox.service';

@Component({
  selector: 'irm-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss']
})
export class SelectComponent {
  theme: string;
  selectedValue: string;
  @Output()
  changeVal: EventEmitter<string> = new EventEmitter();
  @Input()
  list: Array<string>;
  @Input()
  isIncreased: string;
  @Input()
  placeholder = 'Please enter value';
  @Input()
  isDisabled = false;
  @Input()
  isRequired = true;
  

  constructor(
    private overlayContainer: OverlayContainer,
    private themeService: ThemeService,
    private selectboxService: SelectboxService
  ) {
    this.themeService.theme.subscribe(currentTheme => {
      this.theme = currentTheme;
      this.setCurrentTheme();
    });
    this.selectboxService.isClear.subscribe(val => {
      if (val) {
        this.selectedValue = val;
      } else {
        this.selectedValue = undefined;
      }
    });
  }

  onChange(value: string) {
    this.changeVal.emit(value);
  }

  setCurrentTheme() {
    const overlayContainerClasses = this.overlayContainer.getContainerElement().classList;
    const themeClassesToRemove = Array.from(overlayContainerClasses).filter((item: string) => item.includes('-theme'));
    if (themeClassesToRemove.length) {
       overlayContainerClasses.remove(...themeClassesToRemove);
    }
    overlayContainerClasses.add(this.theme);
  }
}
