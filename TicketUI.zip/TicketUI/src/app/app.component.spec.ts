import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ThemeService } from './service/theme/theme.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';


class ThemeServiceMock {
  public theme: BehaviorSubject<string> = new BehaviorSubject('judge-theme');
}
describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let themeService: ThemeService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      schemas      : [ NO_ERRORS_SCHEMA ],
      providers    : [ { provide: ThemeService, useClass: ThemeServiceMock } ]
    }).compileComponents()
    .then(() => {
          fixture = TestBed.createComponent(AppComponent);
          component = fixture.componentInstance;
          themeService = fixture.debugElement.injector.get(ThemeService);
      }
    );
  }));

  it('should create the app', async(() => {
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

  it('setting current theme', async(() => {
    fixture.detectChanges();
    expect(component.theme).toContain('judge-theme');
  }));
});
