import { AuthService } from './service/auth/auth.service';

import { AuthGuard } from './service/auth-guard/auth-guard.service';
import { ThemeService } from './service/theme/theme.service';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ProgressBarModule } from "angular-progress-bar"
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { NgmaterialModule } from '../app/module/ngmaterial/ngmaterial.module';
import { Routing } from './app.routing';

import { AppComponent } from './app.component';
import { HostDashboardComponent } from './hostdashboard/hostdashboard.component';
import { UserDashboardComponent } from './userdashboard/userdashboard.component';
import { LoginComponent } from './login/login.component';
import { NoAccessComponent } from './noaccess/noaccess.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';

import { SelectComponent } from './shared/select/select.component';
import { PersonapageComponent } from './personapage/personapage.component';
import { DatefilterPipe } from './custom-filter/datefilter.pipe';
import { NewEventDialogComponent } from './dialog/new-event-dialog/new-event-dialog.component';
import { TicketDetailDialogComponent } from './dialog/ticket-detail-dialog/ticket-detail-dialog.component';
import { SearchResultPipe } from './custom-filter/searchresult.pipe';
//end onchain
import { SelectboxService } from './service/selectbox-clear/selectbox.service';
import { DatepickerFormat } from './module/datepicker-format/datepicker-format.module';

import { RxReactiveDynamicFormsModule } from "@rxweb/reactive-dynamic-forms"
import { RxReactiveFormsModule } from "@rxweb/reactive-form-validators"

@NgModule({
  declarations: [
    AppComponent,
   
    LoginComponent,
    NoAccessComponent,
    HeaderComponent,
    HomeComponent,
    SelectComponent,
    PersonapageComponent,
       DatefilterPipe,
    SearchResultPipe,
    
    NewEventDialogComponent,
    TicketDetailDialogComponent,
       
       HostDashboardComponent,
       UserDashboardComponent,
    


  ],
  imports: [
    BrowserModule,
    HttpModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    RxReactiveFormsModule,
    RxReactiveDynamicFormsModule ,
    Routing,
    NgmaterialModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    DatepickerFormat,
    ProgressBarModule
  ],
  providers: [

    AuthService,
    AuthGuard,
    ThemeService,
    DatefilterPipe,
    SelectboxService,
    SearchResultPipe
  ],
  entryComponents: [
    TicketDetailDialogComponent,
    
    NewEventDialogComponent,
    
           HostDashboardComponent,
           UserDashboardComponent,
   
   
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
