import Utils from './utils';
import 'rxjs/add/observable/throw';
import { NotFoundError } from './commonerror/not-found-error';
import { AppError } from './commonerror/app-error';
import { ServerError } from './commonerror/server-error';
import { ResponseOptions, Response } from '@angular/http';

describe('Utils', () => {

  it('date formate check', () => {
    const modifiedDate = Utils.changeDateFormate('1536839136161');
    expect(modifiedDate).toBe('13-Sep-2018 17:15');
  });

  it('handle responce 404', () => {
    const error = new Response(new ResponseOptions({
      status: 404
    }));
    const responce = Utils.handleError(error);
    expect(responce).toThrow(new NotFoundError());
  });

  it('handle responce 500', () => {
    const error = new Response(new ResponseOptions({
      status: 500
  }));
    const responce = Utils.handleError(error);
    expect(responce).toThrow(new ServerError());
  });

  it('handle responce Apperror', () => {
    const error = new Response(new ResponseOptions({
      status: 300
  }));
    const responce = Utils.handleError(error);
    expect(responce).toThrow(new AppError());
  });

});
