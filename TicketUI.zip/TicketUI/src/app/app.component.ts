import { Component, OnInit, OnDestroy } from '@angular/core';
import { ThemeService } from './service/theme/theme.service';
import { THEME_KEY } from './app.constant';

@Component({
  selector: 'irm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  theme: string;


  constructor(private themeService: ThemeService) {
    this.themeService.theme.subscribe(currentTheme => {
      this.theme = currentTheme;
    });
  }

  /**
   * Setting current theme
   * @memberof AppComponent
   */
  ngOnInit() {
    const currentTheme = sessionStorage.getItem(THEME_KEY);
    if (currentTheme) {
      this.themeService.theme.next(currentTheme);
    }
  }
}
