import { Component, Inject, OnInit, EventEmitter } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { AgentDetail } from '../../models/Agentdetail.interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { AGENT_UPDATE_TRANSACTION } from '../../app.constant';
import { AuthService } from '../../service/auth/auth.service';
import Utils from '../../utils';
import { SellerDetail } from 'src/app/models/sellerdetail.interface';


@Component({
  selector: 'irm-case-detail-dialog',
  templateUrl: './ticket-detail-dialog.component.html',
  styleUrls: ['./ticket-detail-dialog.component.scss']
})
export class TicketDetailDialogComponent implements OnInit {
 imageHash: string;
  isDisabled = true;
  isLoadingResults = false;
  showTransactionMessage = false;
  message: string;
  agentDetailForm: FormGroup;
  currentPersona: string;
 
  disableDropDown = true;
  dropdownVal: string;
  propertyName: string;
  propertyAddress: string;
  sellerRemark: string;
  sellerMobileno: string;
  // Min moment: Aug 01 2018, 20:30
  min = new Date(2018, 7, 1, 20, 30);
  max = new Date();
  selectedCalDate;
  isTransectionHashGenerated: EventEmitter<boolean> = new EventEmitter();
  constructor(
    private _formBuilder: FormBuilder,
    
    private authService: AuthService,
    private dialogRef: MatDialogRef<TicketDetailDialogComponent>,
    
    @Inject(MAT_DIALOG_DATA) public data: SellerDetail) {
   
    this.agentDetailForm = this._formBuilder.group({
      
      eventId: [{value: this.data.eventId, disabled: true}],
      eventName: [{ value: this.data.eventName, disabled: this.isDisabled }, [Validators.required]],
      eventDescription: [{ value: this.data.eventDescription, disabled: this.isDisabled }, [Validators.required]],
      eventDate: [{ value: this.data.eventDate, disabled: this.isDisabled }, [Validators.required]],
      imageHash: [{ value: this.data.imageHash, disabled: this.isDisabled }, [Validators.required]],
       
        
      
    });

    console.log("this.agentDetailForm ----", this.agentDetailForm )
  }

  /**
   *
   * Initializing case popup with case data.
   * @memberof CaseDetailDialogComponent
   */
  ngOnInit() {
    console.log("hiiiiiiiiiiii____",this.agentDetailForm.value);
    this.imageHash=this.agentDetailForm.value.imageHash;
    this.currentPersona = this.authService.currentUserDetails.persona;
  }

  /**
   *
   * Enabling and disabling input value
   * @memberof CaseDetailDialogComponent
   */
  handleChange(): void {
    const agentAddress = this.agentDetailForm.get('agentAddress');
    const agentMobile = this.agentDetailForm.get('agentMobile');
    const agentRemark = this.agentDetailForm.get('agentRemark');
 
    if (!this.isDisabled) {
      agentAddress.enable();
      agentMobile.enable();
      agentRemark.enable();
      
    }
  }

  /**
   *
   * Persisting case data
   * @memberof CaseDetailDialogComponent
   */
  
  /**
   *
   * Closing dialog box
   * @memberof CaseDetailDialogComponent
   */
  closeDialog(): void {
    this.dialogRef.close();
  }

}
