import { Component, OnInit, Inject, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators,  } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatPaginator, MatTableDataSource, MatDialogConfig } from '@angular/material';

//import { SellerService } from '../../service/seller/seller.service';
import { EventService } from '../../service/event/event.service';
import { SellerDetail } from '../../models/sellerdetail.interface';
import { PROPERTY_CREATE_TRANSACTION, USER_ROLE_DROPDOWN, FORM_TEMPLETE_EVENT, MARTIAL__DROPDOWN} from '../../app.constant';
import { AuthService } from '../../service/auth/auth.service';
import Utils from '../../utils';

import { MatDialog } from '@angular/material';




@Component({
  selector: 'irm-new-case-dialog',
  templateUrl: './new-event-dialog.component.html',
  styleUrls: ['./new-event-dialog.component.scss']
})
export class NewEventDialogComponent implements OnInit {
  isLoadingResults = false;
  showTransactionMessage = false;
  progressBar: Number;
  message: string;
  dropdownList = USER_ROLE_DROPDOWN;
  //marrieddropdownList = MARTIAL__DROPDOWN;
  formTemplate = FORM_TEMPLETE_EVENT;
  dropdownVal: string;
  eventCreateForm: FormGroup;
  isTransectionHashGenerated: EventEmitter<boolean> = new EventEmitter();
  // Min moment: Aug 01 2018, 20:30
  min = new Date(2018, 7, 1, 20, 30);
  max = new Date();
emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";

  constructor(
    private _formBuilder: FormBuilder,
    private dialog: MatDialog,
    private dialogRef: MatDialogRef<NewEventDialogComponent>,
    // private caseService: CaseService,
    private eventService: EventService,
    private authService: AuthService,
    @Inject(MAT_DIALOG_DATA) public data: SellerDetail) {
   

  }
  /**
   *
   * Initializing form builder with case properties.
   * @memberof NewSellerDialogComponent
   */
  ngOnInit() {
    this.progressBar =0;
    this.eventCreateForm = this._formBuilder.group({
     
      eventName: ['', [Validators.required]],
      eventDescription: ['', [Validators.required]],
      eventDate: ['', [Validators.required]],
      numberTicket: ['', [Validators.required]],
      profile: ['', [Validators.required]]
        });

  }
  onFileChange(event) {

    if (event.target.files.length > 0) {

      const file = event.target.files[0];
console.log("file",file)
      this.eventCreateForm.get('profile').setValue(file);
    }
  }
  /**
   *
   * Creating Event.
    */
  createEvent(): void {
    const createdBy = this.authService.currentUserDetails.name;
   console.log("this.eventCreateForm.value",this.eventCreateForm.value)

    
   // this.propertyCreateForm.value['maritalStatus'] = this.dropdownVal;
        //this.sellerService.createSeller(this.eventCreateForm.value).subscribe(({result}) => {
      this.eventService.createEvent(this.eventCreateForm.value).subscribe(({ result }) => {
        this.isLoadingResults = false;
        this.showTransactionMessage = true;
        this.isTransectionHashGenerated.emit(true);
        this.message = PROPERTY_CREATE_TRANSACTION
        .replace('@@userName@@', createdBy)
        .replace('@@date@@', Utils.changeDateFormate());
      });
           
 
  }

 /**
   *
   * Closing dialog box
   * @memberof CaseDetailDialogComponent
   */
  closeDialog(): void {
    this.dialogRef.close();
  }
}
