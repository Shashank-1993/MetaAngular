import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import { NotFoundError } from './commonerror/not-found-error';
import { AppError } from './commonerror/app-error';
import { ServerError } from './commonerror/server-error';


export default class Utils {
    /**
     *
     * Convert given date to DD-MMM-YYYY HH:MM.
     * @param {string} [date]
     * @memberof SharedMethods
     */
    static changeDateFormate(date?: string): string {
        const dateObj = date ? new Date(date) : new Date();
        const dateStringArry = dateObj.toDateString().split(' ');
        const timeStringArry = dateObj.toTimeString().split(':');
        return `${dateStringArry[2]}-${dateStringArry[1]}-${dateStringArry[3]} ${timeStringArry[0]}:${timeStringArry[1]}`;
    }

    /**
     *
     * Handling application based errors.
     * @static
     * @param {any} error
     * @returns
     * @memberof Utils
     */
    static handleError(error: any) {
        if (error.status === 404 || error.status === 405) {
            return Observable.throw(new NotFoundError());
        } else if (error.status === 500) {
            return Observable.throw(new ServerError());
        }
        return Observable.throw(new AppError(error));
      }
}
