import { AuthService } from '../service/auth/auth.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppError } from '../commonerror/app-error';
import { NotFoundError } from '../commonerror/not-found-error';
import { PERSONA_NAME, JWT_TOKEN_KEY, THEME_KEY } from '../app.constant';

@Component({
  selector: 'irm-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  invalidLogin: boolean;
  invalidRole: boolean;
  showLogin: boolean;
  selectedRole: string;
  displayedRole: string;
  showSpinner = false;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService) { }

  /**
   *
   * Initializing theme and login details.
   * @memberof LoginComponent
   */
  ngOnInit() {
    sessionStorage.removeItem(JWT_TOKEN_KEY);
    sessionStorage.removeItem(THEME_KEY);
    this.showLogin = false;
    this.invalidLogin = false;
    this.invalidRole = false;
  }

  /**
   *
   * Setting current persona role.
   * @param {string} role
   * @memberof LoginComponent
   */
  setCurrentRole(role: string): void {
    this.displayedRole = PERSONA_NAME[role];
    this.selectedRole = role;
  }

  /**
   *
   * Reseting login details.
   * @memberof LoginComponent
   */
  resetLogin() {
    this.showLogin = false;
    this.invalidLogin = false;
    this.invalidRole = false;
  }

  /**
   *
   * Checking login credentials.
   * @param {*} credentials
   * @memberof LoginComponent
   */
  login(credentials: any): void {
    this.showSpinner = true;
    this.authService.login(credentials)
      .subscribe(result => {
        if (result) {
           if (this.authService.currentUserDetails.persona=='Seller' ){
            const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
            this.router.navigate([returnUrl === '/' ? 'Seller' : returnUrl || 'Seller']);
          } else if (this.authService.currentUserDetails.persona == 'Agent') {
            const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
            this.router.navigate([returnUrl === '/' ? 'Agent' : returnUrl || 'Agent']);
          } else if (this.authService.currentUserDetails.persona == 'Buyer') {
            const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
            this.router.navigate([returnUrl === '/' ? 'Buyer' : returnUrl || 'Buyer']);
          }

        } else {
          this.invalidLogin = true;
          this.invalidRole = false;
          this.showSpinner = false;
        }
      },
      (error: AppError) => {
        if (error instanceof NotFoundError) {
          this.invalidLogin = true;
          this.invalidRole = false;
          this.showSpinner = false;
        } else {
          throw error;
        }
      });
  }

}
