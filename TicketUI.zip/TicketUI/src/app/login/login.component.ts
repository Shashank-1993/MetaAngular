import { AuthService } from './../service/auth/auth.service';
import { Component, OnInit, ViewChild } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { AppError } from '../commonerror/app-error';
import { NotFoundError } from '../commonerror/not-found-error';
import { PERSONA_NAME, JWT_TOKEN_KEY, THEME_KEY } from '../app.constant';
import { MatPaginator, MatTableDataSource, MatDialogConfig } from '@angular/material';
import { MatDialog } from '@angular/material';


@Component({
  selector: 'irm-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  invalidLogin: boolean;
  invalidRole: boolean;
  showLogin: boolean;
  selectedRole: string;
  displayedRole: string;
  showSpinner = false;
  isLoadingResults: boolean;
  isSearchDone: boolean;
  hideNoDataFound: boolean;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,

    private dialog: MatDialog) { }

  /**
   *
   * Initializing theme and login details.
   * @memberof LoginComponent
   */
  ngOnInit() {
    sessionStorage.removeItem(JWT_TOKEN_KEY);
    sessionStorage.removeItem(THEME_KEY);
    this.showLogin = true;
    this.invalidLogin = false;
    this.invalidRole = false;

  }




  /**
   *
   * Setting current persona role.
   * @param {string} role
   * @memberof LoginComponent
   */
  setCurrentRole(role: string): void {
    this.displayedRole = PERSONA_NAME[role];
    this.selectedRole = role;
  }

  /**
   *
   * Reseting login details.
   * @memberof LoginComponent
   */
  resetLogin() {
    this.showLogin = false;
    this.invalidLogin = false;
    this.invalidRole = false;
  }

  /**
   *
   * Checking login credentials.
   * @param {*} credentials
   * @memberof LoginComponent
   */
  login(credentials: any): void {
    this.showSpinner = true;
    this.authService.login(credentials)
      .subscribe(result => {
        if (result) {

          this.invalidRole = true;
          this.invalidLogin = false;
          this.showSpinner = false;
          console.log("hi-------", this.authService.currentUserDetails.persona);
          const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
       //   this.router.navigate([returnUrl === '/' ? 'Dashboard' : returnUrl || 'Dashboard']);
          if (this.authService.currentUserDetails.persona =='host')
          this.router.navigate([returnUrl === '/' ? 'hostdashboard' : returnUrl || 'hostdashboard']);
          else if (this.authService.currentUserDetails.persona == 'User')
            this.router.navigate([returnUrl === '/' ? 'hostdashboard' : returnUrl || 'hostdashboard']);
                  } else {
          this.invalidLogin = true;
          this.invalidRole = false;
          this.showSpinner = false;
        }
      },
        (error: AppError) => {
          if (error instanceof NotFoundError) {
            this.invalidLogin = true;
            this.invalidRole = false;
            this.showSpinner = false;
          } else {
            throw error;
          }
        });
  }
}
  
