import { DatepickerFormat } from './datepicker-format.module';

describe('DatepickerFormat', () => {
  let datepickerFormat: DatepickerFormat;

  beforeEach(() => {
    datepickerFormat = new DatepickerFormat();
  });

  it('should create an instance', () => {
    expect(datepickerFormat).toBeTruthy();
  });
});
