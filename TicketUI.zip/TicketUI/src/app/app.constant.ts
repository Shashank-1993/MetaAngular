import { SellerDetail } from './models/sellerdetail.interface';
import { AgentDetail } from './models/agentdetail.interface';
import { BuyerDetail } from './models/buyerdetail.interface';
import { TransactionDetail } from './models/transactiondetail.interface';
import Utils from './utils';

// APP KEY
export const APP_KEY = '534C6EEDC9EE2BD4E9EAE563D5A0379A3448A4F90B213F1E45BCDE45D6E3EDE4';

// API urls
export const LOGIN_API = '/api/user/authenticate';
export const ENROLL_USER_API = '/api/user/insertUser';
export const SELLER_API = '/api/seller';
export const SELLER_PROPERTY_DETAILS_API = '/api/seller/propertydetails';
export const OFFER_DATE_API = '/api/seller/addOfferDate';
export const PURCHASE_PRICE_API = '/api/buyer/purchasePrice';
export const SUSPENSIVE_API = '/api/seller/suspensiveCondition';
export const OCUPATION_API = '/api/seller/occupation';
export const FIXTURE_API = '/api/seller/addFixture';
export const OTHER_TEAM_CONDITION_API = '/api/seller/otherTermCondition';
export const WITNESS_API = '/api/seller/witness';

export const OFFCHAIN_DATA_API = '/api/seller/findByApplicationId';
export const ONCHAIN_SELLER_DATA_API = '/api/seller/findOnchain';
export const ONCHAIN_BUYER_DATA_API = '/api/buyer/findAllBuyerListOnChain';
export const UPDATE_STATUS_API = '/api/seller/updateRemark';
export const UPDATE_DOCUSIGN_STATUS_API = '/api/seller/docusign/updateStatus';
export const GET_APPLICATION_FORM_API = '/api/seller/findOnchainapplicationId';
export const UPDATE_PRE_GRANT_STATUS_API = '/api/seller/updatePreGrant';


export const SELLER_LISTING_API = '/api/seller/findByUserId';
export const SELLER_PROPERTY_TO_AGENT = '/api/seller/sendagent';

export const TRANSACTION_API = '/api/transaction/findByPropertyId';
export const DETAILS_BY_TRANSACTION_ID = '/api/transaction/findByTransactionId';
export const LATEST_BLOCK_API = '/api/block/findCurrentBlock';
export const AGENT_API = '/api/agent';
export const SEND_TO_AGENT__API = '/api/seller/findSendToAgentList';
export const ALL_AGENT_DASHBOARD_API = '/api/agent/findAllByAgentId';

export const SEND_TO_BUYER_API = '/api/agent/sendToBuyer';
export const UPDATE_SELLER_REMARK_API = '/api/seller/updateComment';

export const ALL_BUYER_LIST_API = '/api/buyer/findAll';
export const CREATE_EVENT_API = '/api/createEvent';
export const FINDALL_EVENT_API = '/api/findAll';
export const ALL_BUYER_DASHBOARD_API = '/api/buyer/findAllListBuyerDashboard';
export const ALL_BUYER_REMARK_LIST_API = '/api/seller/findBuyerCommentBySellerId';
export const UPDATE_AGENT_RATE_API = '/api/seller/updateAgentCommissionRate';
export const GET_SELLER_DETAILS_BY_PROPERTY_ID_API = '/api/seller/findByProperty';
export const GET_BUYER_DETAILS_BY_BUYER_ID_API = '/api/buyer/findBybuyer';
export const UPDATE_BUYER_API = '/api/buyer/updateBuyer';
export const GET_BUYER_FILE = '/api/buyer/fileDownload';
export const CHECK_USER_NAME_API = '/api/user/userNameExist';
export const GET_BUYER_FILE_DOWNLOAD_API = 'https://docusign-integration-function.azurewebsites.net/api/download/';



// Default theme
export const DEFAULT_THEME = 'default-theme';

// Snack bar properties
export const SNACKBAR_TIMEOUT = 10000;
 
// Session storage key
export const JWT_TOKEN_KEY = 'token';
export const THEME_KEY = 'theme';

// Persona based evidence life cycle tracking
export const PERSONA_NAME = {
    Seller: 'Seller',
    Buyer: 'Buyer',
    Judicial_Agent: 'Judicial',
    Agent: 'Agent',
    Auditor: 'Auditor'
};


// Paginator size array
export const PAGINATOR_SIZE_ARRAY = [10, 15, 20, 25, 50, 75, 100];

// Dropdown


export const USER_ROLE_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'agent',
    value: 'Agent'
  },
  {
    key: 'buyer',
    value: 'Buyer'
  },

  {
    key: 'seller',
    value: 'Seller'
  }
];

export const BUYER_SEARCH_DASHBOARD_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'propertyId',
    value: 'Property Id'
  },
  {
    key: 'agentId',
    value: 'Agent Id'
  },
  
  {
    key: 'createdDate',
    value: ' Created Date'
  }
];

export const MARTIAL__DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'Married',
    value: 'Married'
  },
  {
    key: 'unMarried',
    value: 'unMarried'
  }


];

export const EMPLOYMENT_TYPE_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'FullTime ',
    value: 'Full Time '
  },
  {
    key: 'partTime',
    value: 'Part Time'
  },
  {
    key: 'contract',
    value: 'Contract '
  }


];
export const BUYER_SELLER_SEARCH_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'propertyId',
    value: 'Property Id'
  },
 
  {
    key: 'createdDate',
    value: 'Date'
  }
];



export const BUYER_SEARCH_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'propertyId',
    value: 'Property Id'
  },
  {
    key: 'agentId',
    value: 'Agent Id'
  },
  {
    key: 'buyerId',
    value: 'Buyer Id'
  },
  {
    key: 'createdDate',
    value: 'Date'
  }
];

export const AGENT_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'Njongwezintle',
    value: 'Njongwezintle'
  },
  {
    key: 'Lisa',
    value: 'Lisa'
  },
  
];


export const BUYER_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'Meyer',
    value: 'Meyer'
  },
  {
    key: 'Wilson',
    value: 'Wilson'
  },

];

export const SELLER_ACTION_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'approved',
    value: 'Approved'
  },
  {
    key: 'reject',
    value: 'Reject'
  },

];
export const SELLER_AGENT_RATE_DROPDOWN: { key: string, value: string }[] = [
  {
    key: 'Accepted',
    value: 'Accepted'
  },
  {
    key: 'Decline',
    value: 'Decline'
  },

];




export const ON_CHAIN_COLUMN: { key: string, value: string, cell: (row: SellerDetail) => string | number }[] = [
  {
    key: 'eventId',
    value: 'Event ID',
    cell: (row: SellerDetail) => `${row.eventId ? row.eventId : '-'}`
  },

  {
    key: 'eventName',
    value: 'Event Name',
    cell: (row: SellerDetail) => `${row.eventName ? row.eventName : '-'}`
  },

  {
    key: 'eventDescription',
    value: 'Event Description',
    cell: (row: SellerDetail) => `${row.eventDescription ? row.eventDescription : '-'}`
  },

  
 
  {
    key: 'eventDate',
    value: 'Event Date',
    cell: (row: SellerDetail) => `${row.eventDate ? row.eventDate : '-'}`
  },
  
 
  {
    key: 'view',
    value: 'View',
    cell: (row: SellerDetail) => `${'-' ? '-'  : '-'}`
  },
];



// Agent Details Column

// Agent Dashboard Column






// Transaction Details Column
export const TRANSACTION_HEADER_COLUMN: { key: string, value: string, cell: (row?: TransactionDetail)  => string|number }[] = [
    {
        key: 'transactionId',
        value: 'Transaction ID',
        cell: (row: TransactionDetail) => `${row.transactionId ? row.transactionId : '-'}`
  },
  {
    key: 'Activity',
    value: 'Activity',
    cell: (row: TransactionDetail) => `${row.operationType ? row.operationType : '-'}`
  },
    {
        key: 'blockNo',
        value: 'Block No',
        cell: (row: TransactionDetail) => `${row.blockNo ? row.blockNo : '-'}`
    },
    {
        key: 'transactionTimeStamp',
        value: 'Date',
        cell: (row: TransactionDetail) => `${Utils.changeDateFormate(row.transactionTimeStamp)}`
    },
    {
        key: 'userName',
        value: 'User',
        cell: (row: TransactionDetail) => `${row.userName ? row.userName : '-'}`
    }
];

// Persona based evidence life cycle tracking
export const EVIDENCE_LIFECYCLE_TRACK = {
    Storage_Agent: 'sentToStorage',
    Lab_Tech: 'sentToLab',
    Judicial_Agent: 'sentToCourt'
};







// Transaction message
export const USER_CREATE_TRANSACTION = '<strong> User has successfully registered <strong>';
export const PROPERTY_CREATE_TRANSACTION = 'Event has been created  successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';

export const BUYER_CREATE_TRANSACTION = 'Purchaser Details saved successfully by <strong>@@userName@@</strong>' +
' at <strong>@@date@@</strong>.';
export const PROPERTY_DETAILS_CREATE_TRANSACTION = 'Property Details saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';

export const TERM_CONDITION_DETAILS_CREATE_TRANSACTION = 'Term and Condition Details saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';
export const PURCHARSE_PRICE_CREATE_TRANSACTION = 'Purchase Price  Details saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';
export const SUSPENSIVE_CREATE_TRANSACTION = 'Suspensive  Details saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';

export const OCCUPATION_CREATE_TRANSACTION = 'Occupation  Details saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';
export const FIXTURE_CREATE_TRANSACTION = 'Fixture  Details saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';

export const OTHER_TERM_CONDITION_CREATE_TRANSACTION = 'Other Term Condition  Details saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';

export const WITNESS_CREATE_TRANSACTION = 'Witness  Details saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.';

export const FINAL_SAVE_CREATE_TRANSACTION = 'Application Id <strong>@@applicationID@@</strong> saved successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';

export const UPDATED_TRANSACTION = 'Status of application Id <strong>@@applicationID@@</strong>has updated successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';


export const AGENT_CREATE_TRANSACTION = 'Agent Id <strong>@@agentID@@</strong> created successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';

export const AGENT_UPDATE_TRANSACTION = 'Agent Id <strong>@@agentID@@</strong> updated successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';

export const SEND_TO_AGENT_TRANSACTION =  'Property Id <strong>@@propertyID@@</strong> send to agent  by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';

export const SEND_TO_BUYER_TRANSACTION = 'Agent Id <strong>@@agentID@@</strong> send to buyer  by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';


export const BUYER_UPDATE_TRANSACTION = 'Buyer Id <strong>@@buyerID@@</strong> updated successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';

export const UPDATE_SELLER_REMARK_TRANSACTION = 'buyer Id <strong>@@buyerID@@</strong> has updated  remarks successfully by <strong>@@userName@@</strong>' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';


export const CREATE_STATE_TRANSACTION = 'State <strong>@@caseID@@</strong> added successfully by <strong>@@userName@@</strong>' +
                                        ' at <strong>@@date@@</strong>.' +
                                        ' Transaction hash generated <strong>@@hash@@</strong>';
export const AGENT_UPDATE_RATE_TRANSACTION = '<strong>@@userName@@</strong> has successfully updated commission rate for Property Id <strong>@@propertyID@@</strong> ' +
  ' at <strong>@@date@@</strong>.' +
  ' Transaction hash generated <strong>@@hash@@</strong>';


export const FORM_TEMPLETE_EVENT = [
  

  {
    key: 'Event Title',
    type: "textBox",
    value: "eventTitle",
    
  },

   {
    key: 'Description',
    type: "textBox",
    value: "discription",
  },
  {
    key: 'Number Of Ticket',
    type: "textBox",
    value: "ticketNumber",
  },
  {
    "key": 'Date',
    "type": "date",
    "value": "offerdate",
  },
  
  
 
  
  
]

export const FORM_TEMPLETE_BUYER = [


  {
    "key": 'Full Name',
    "type": "textBox",
    "value": "buyerFullName",

  },

  {
    "key": 'Passport Number',
    "type": "textBox",
    "value": "buyerPassportNumber",
  },
  {
    "key": 'Spouse Name',
    "type": "textBox",
    "value": "buyerSpouseName",
  },
  {
    "key": 'Marital Status',
    "type": "textBox",
    "value": "buyerMaritalStatus",
  },
  {
    "key": 'postal Address',
    "type": "textBox",
    "value": "buyerPostalAddress",
  },
  {
    "key": 'Email',
    "type": "textBox",
    "value": "buyerEmail",
  },
  {
    "key": 'Phone Number',
    "type": "textBox",
    "value": "buyerPhoneNumber",
  },

  {
    "key": 'Fax Number',
    "type": "textBox",
    "value": "buyerFaxNumber",
  }, {
    "key": 'Sars Tax Number',
    "type": "textBox",
    "value": "buyerSarstaxNumber",
  },
  {
    "key": 'Vat Registration Number',
    "type": "textBox",
    "value": "buyerVatnumber",
  }, {
    "key": 'Conveyancers',
    "type": "textBox",
    "value": "buyerConveyancers",
  },
  {
    "key": 'Property Bonded To',
    "type": "textBox",
    "value": "buyerPropertyBonded",
  }, {
    "key": 'Bonded Account Number',
    "type": "textBox",
    "value": "buyerBondedAccountNumber",
  }


]

export const FORM_TEMPLETE_PROPERTY_DETAILS = [


  {
    "key": 'ERF Number/Township: ',
    "type": "textBox",
    "value": "erfNumber",

  },

  {
    "key": 'Erf size measuring approximately: ',
    "type": "textBox",
    "value": "erfSize",
  },
  {
    "key": 'Physical Address:',
    "type": "textBox",
    "value": "erfAddress",
  }]


export const FORM_TEMPLETE_TERM_CONDITION_DETAILS = [


  {
    "key": 'The terms and conditions of sale of Property(“Terms and Conditions”) set out in this document, the Schedule and Particulars and any annexures hereto together constitute the agreement between the parties(“the Agreement”).Unless otherwise indicated by the context, capitalised words and expressions in these Terms and Conditionswill have the meanings given to them in theseTerms and Conditions and the Schedule of Particulars'+
      'to whichthese Terms and Conditions are attached.' +'\n\n\n',
    "type": "label",
    "value": "",

  },

  {
    "key": 'In this Agreement : ',
    "type": "label",
    "value": "",
  },
  {
    "key": '* Any reference to “business day” will be any other day than a Saturday, Sunday or public holiday as gazetted by the Government of the Republic of South Africa from time to time',
    "type": "label",
    "value": "",
  },
  {
    "key": '1    PURCHASE AND SALE',
    "type": "heading",
    "value": "",
  },
  {
    "key": 'he Purchaser hereby offers to purchase theProperty referred to in the Schedule of Particulars on the terms and conditions contained in this Agreement.',
    "type": "label",
    "value": "",
  },
  {
    "key": '2    OFFER AND ACCEPTANCE',
    "type": "heading",
    "value": "",
  },

  {
    "key": 'he Purchaser’s offer shall constitute an irrevocable offer, which may not be withdrawn prior to presentation to the Sellerand whichoffershall remain available for acceptance until .',
    "type": "label",
    "value": "",
  },

  {
    "key": 'Date',
    "type": "date",
    "value": "offerdate",
  },
  
  {
    "key": 'where afterit shall lapse and be of no further force and effect.',
    "type": "label",
    "value": "",
  },

  {
    "key": '3    CONSUMER PROTECTION ACT 68 OF 2008 (“CPA”)',
    "type": "heading",
    "value": "",
  },
  {
    "key": ' The Seller confirms that he / she / it is NOT selling the Property in the ordinary course of his / hers / its business and that to the best of his / hers / its knowledge the CPA does not apply to this Agreement.',
    "type": "label",
    "value": "",
  },
  {
    "key": '4    VOETSTOETS',
    "type": "heading",
    "value": "",
  },
  {
    "key": ' *  The Seller warrants that as at the date of acceptance of this offer there are no latent defects in the Property known to the Seller and that save for this, the Property is sold voetstoets.',
    "type": "label",
    "value": "",
  },
  {
    "key": ' *  he Property is sold subject to all conditions and servitudes mentioned or referred to in its TitleDeed and to all such other conditions and servitudes which may be applicable.  If the property is erroneously described in the Schedule of Particulars, the intention of the parties is to describe the Property as set out in the Title Deed .',
    "type": "label",
    "value": "",
  },
  {
    "key": ' *  The Seller shall not benefit by any excess or be liable for any deficiency in the area of the Property.',
    "type": "label",
    "value": "",
  },
  {
    "key": ' *  The Property is sold “voetstoets”.',
    "type": "label",
    "value": "",
  },
]
export const FORM_TEMPLETE_PURCHASE_PRICE = [


  {
    "key": 'The purchase price is ',
    "type": "label",
    "value": "",

  },

  {
    "key": 'Amount(Rand): ',
    "type": "textBox",
    "value": "purchasePrice",
  },
  {
    "key": ' A DEPOSIT of R',
    "type": "label",
    "value": "",

  },
  {
    "key": 'Amount(Rand): ',
    "type": "textBox",
    "value": "depositAmt",
  },
  {
    "key": ' 5.1 by cheque or electronic transfer payable within',
    "type": "label",
    "value": "",

  },
  {
    "key": 'Business Day ',
    "type": "textBox",
    "value": "chequeBusinessDay",
  },

  {
    "key": '  of acceptance of this offer, to be deposited with the Conveyancer’s, which amount will be deposited and held in trust in an interest bearing account on behalf and for the benefit of the Purchaser pending registration of transfer.',
    "type": "label",
    "value": "",

  },
  {
    "key": '5.2  The balance of the Purchase Price in the amount of ',
    "type": "label",
    "value": "",

  },
  {
    "key": 'Amount(Rand): ',
    "type": "textBox",
    "value": "balanceAmount",
  },
  {
    "key": 'shall   be   paid   to   the Conveyancing Attorneys(“Conveyancers”)  appointed  by  the  Seller against  registration  of  transfer  of  the  Property(“Transfer”)',
    "type": "label",
    "value": "",

  },

  {
    "key": ' 5.3 The Balance of the Purchase Price will be secured by bank or other guarantees, acceptable by the Conveyancers andto be delivered to the Conveyancers within ',
    "type": "label",
    "value": "",

  },
  {
    "key": 'Business Day ',
    "type": "textBox",
    "value": "conveyancersBusinessDay",
  },
  {
    "key": ' business days after fulfilmentor waiver of the Suspensive Conditions referred to in clause 6.1, if applicable.',
    "type": "label",
    "value": "",

  },
  ]
export const FORM_TEMPLETE_SUSPENSIVE = [


  {
    "key": ' 6.1 This sale is subject to the condition that the Purchaseror the Agent, on the Purchaser’sbehalf,is  able  to  raise  a  loan  upon  the  security  of  a  first  mortgage  bond  to  be  passed  over  the Property  for',
    "type": "label",
    "value": "",

  },

  {
    "key": 'Amount(Rand): ',
    "type": "textBox",
    "value": "suspensiveAmt",
  },
  {
    "key": 'at  prevailing  bank  terms and  conditions,  on  or  before ',
    "type": "label",
    "value": "",

  },
  {
    "key": 'Business Day ',
    "type": "textBox",
    "value": "suspensiveDay",
  },
  

  {
    "key": 'he Purchaserundertakes timeously to take all steps and sign all documents and do all such things that may be necessary to procure the loan and comply with requirements of the lender. The Purchaserwarrants that they have sufficient income for the requirements for the proposed mortgage for the approval of  the  said  loan,  and  that  as  far  as  they  are  aware  no  factors  exist  which  might  preventthe granting of the loan.',
    "type": "label",
    "value": "",

  },
  

  {
    "key": ' 6.2  The Suspensive Condition  set  out in  clause  6.1 shall be  deemed  to  have  been fulfilled  on  the date   upon   which   the   Mortgage   Lender   issues   a   written   loan   quotation   or   similar documentation approving or offering the loan sought to the Purchaser.',
    "type": "label",
    "value": "",

  },
  {
    "key": '6.3 The Suspensive Condition has been inserted for the benefit of the Purchaser who/which may waive the Suspensive Condition by his/her/its actions or by giving notice in writing to the Seller at any time prior to the date of fulfilmentor waiver.',
    "type": "label",
    "value": "",

  },
  
  {
    "key": '6.4 The  parties  agree  that  the fulfilmentof  the  Suspensive  Condition  will  automatically  be extended by 14 (fourteen) days.',
    "type": "label",
    "value": "",

  },

  {
    "key": ' 6.5 f the Suspensive Condition is not fulfilled or waived by the due date, then this Agreement shall become  null  and  void  and  the  Deposit  and  any  interest  thereon,  shall  be repaidto  the Purchaser within 5 (five) business days after such date.',
    "type": "label",
    "value": "",

  }
 
]


export const FORM_TEMPLETE_OCCUPATION = [


  {
    "key": ' 7.1 Occupation  of  the  property  shall  be  given  to  the Purchaseron TRANSFER("the  occupation date"), by which date the Sellerand anyother occupier shall vacate the property. ',
    "type": "label",
    "value": "",

  },

 
  {
    "key": ' 7.2 No right  of  tenancy shall be acquired  by  the Purchaser  in  the  event  that  the Purchaser  takes occupation of the Property prior to registration of transfer. Accordingly, in the event that this agreement is cancelled, the Purchaser shall immediately vacate the Property. ',
    "type": "label",
    "value": "",

  },


  {
    "key": ' 7.3 If the transfer date is after the occupation date, the person enjoying suchoccupation, shall pay to  the Conveyancerfor  the  period  from date  of OCCUPATION  to  the  transfer  date  a consideration for such occupation at the rate of ',
    "type": "label",
    "value": "",

  },
  {
    "key": 'Amount(Rand) Per Month: ',
    "type": "textBox",
    "value": "amountPerMonth",
  },
 


  {
    "key": ' 7.4 The consideration will be calculated and payable monthly in advance on the first day of each month commencing from the first day of the month during which the occupation date may be.',
    "type": "label",
    "value": "",

  },


  


]
export const FORM_TEMPLETE_PROCESSION = [


  {
    "key": 'Possession  and  ownership  of  and  all  benefits  and  risk  in  the  Property  shall  pass  to  the  Purchaser against transfer  from which date the Purchaser shall liable for, amongst other things, all rates, taxes and/or levies pertaining to the Property. Prepayments made by either party for any period subsequent to  Transfer shall  be adjusted proportionately.    The  Seller shall maintain adequate insurance  cover  on the Propertyuntil Transfer.',
    "type": "label",
    "value": "",

  }]

export const FORM_TEMPLETE_RISK = [


  {
    "key": '9.1 From the date of registration of transfer of the Property into the name of the Purchaser("the transfer date") -',
    "type": "label",
    "value": "",

  },
   {
     "key": '9.1.1 all the benefits and risks of ownership of the property shall pass to the Purchaser;',
    "type": "sublabel",
    "value": "",

  },
    {
      "key": '9.1.2  the  Purchasershall  be  liable  for  all  rates,  taxes,  water  and  electricity levied  on  the property.',
    "type": "sublabel",
    "value": "",

  },
  {
    "key": '9.2He Purchaser shall not be entitled to effect any improvements or alterations to the Propertyprior to registration of transfer. If, however, any improvements or alterations are so effected and  this  agreement is  thereafter  cancelled,  then  in  such  event  the  Sellershall  be  entitled,  at the  Seller’soption,  to  demand  from  the  Purchaserthat  the  Propertybe  restored  to  its unaltered  condition,  alternatively  the  Sellermay  elect  to  accept  such  improvements  and/or alterations without anycompensation being payable to the Purchaser.',
    "type": "label",
    "value": "",

  },

]
export const FORM_TEMPLETE_FIXTURE = [


  {
    "key": 'The Property is sold together with all fixtures and fittings of a permanent nature in or attached to the Property  including  the  following:  automatic  garage  door  and  gate  mechanism/swith  the  remote control/s;  automatic  pool  cleaning  equipment,  pool  pump,  filter,  chlorinator,  burglar  alarm  system, fitted burglarbars and security gates,built in oven, hob and extractor fan, curtain rods,rings, rails and blinds,  electric  light  fittings  and  chandeliers,  fitted  carpets,  fitted  cupboards,  shelves,  fitted  mirrors, irrigation system, TV aerial, satellitedish and',
    "type": "label",
    "value": "",

  },
  {
    "key": 'Any Other',
    "type": "textarea",
    "value": "anyOtherFixture",

  },
  {
    "key": ' The  Seller warrants  that  the  fixtures  and  fittings  form  part  of  the  Property  and  are  owned  by  theSeller  and  are in working  order as at  the  date  of  Transfer  or  date  of  occupation, whichever  occur first.',
    "type": "heading",
    "value": "",

  }
 

]

export const FORM_TEMPLETE_ELECTICAL_GAS = [


  {
    "key": '11.1  The  Sellershall,  prior  to lodgementof  transfer, furnish  the Conveyancer with  a  certificate  of compliance   in   terms   of   the   Electrical   Installation   Regulations,2009,   issuedunder   the Occupational Health and Safety Act 85 of 1993 (“OHSA”). Insofar as the accredited electrician appointed by the Seller to provide such certificate requires remedial or rectification electrical work to be carried out as a precondition to the issue of such certificate, the Seller will procure that  such  work is  carried  out  and  will  do  so  at  the  Seller’s  sole  cost  and  expense.    The certificate shall not pre-date the date of Transfer by more that 2 (two) years.',
    "type": "label",
    "value": "",

  },
  
  {
    "key": ' 11.2 Where a Gas Installation is situated on the Propertyand ownership of such installation will vest in the Purchaser after Transfer, the Seller shall provide the Purchaser, by delivery to the Conveyancers with a certificate of conformity issued by an authorised person in terms of Government Regulation No. 734 of 2009, by no later than date of lodgement.  ”). Insofar as the authorised personappointed by the Seller to provide such certificate requires remedial or rectification electrical work to be carried out as a precondition to the issue of such certificate, the Seller will procure that such work  is carried out and will do so at the Seller’s sole cost and expense.  The certificate shall not pre-date the date of Transfer by more that 2 (two) years',
    "type": "label",
    "value": "",

  },
  {
    "key": '11.3 Pursuant to the promulgation of the Electrical Machinery Regulations 2011, promulgated in terms of the OHSA, and if applicable the Seller shall, at the Seller’s expense, provide the Purchaser with an Electric Fence System Certificate of Compliance (“the certificate”) prior to date of lodgement.  Suchcertificate shall be issued by a registered electric fence installer in accordance with the provisions of Regulations 12(4) and 13(1) of the Electrical Machinery Regulations 2011 and confirm that the electric fence system is deemed to be reasonably safe when properly used.  The Seller will procure that such work iscarried out and will do so at the Seller’s sole cost and expense.  The certificate shall not pre-date the date of Transfer by more that 2 (two) years',
    "type": "label",
    "value": "",

  }


]

export const FORM_TEMPLETE_BREACH = [


  {
    "key": '13.1 If  either  party  breaches  any  provision  of  this  agreement  and  remains  in  breach  for 7  (seven) days after written noticeby email, telefax or by hand delivery,to such party requiring that party to  rectify  that  breach  or  if  either  party  repudiates  this  agreement,  the  other  party  shall  be entitled at that party election–',
    "type": "label",
    "value": "",

  },
  {
    "key": ' 13.1.1 to  sue  for  the  immediate  specific  performance  of  any  or  all  of  the  defaulting  party obligations under this agreement whether or not any such obligation is then due; or',
    "type": "sublabel",
    "value": "",

  },
  {
    "key": '13.1.2 (either as an alternative to a claim for specific performance or upon the abandonment of such a claim)  to  cancel  this agreement.  Written notice of such cancellation shall be given to the defaulting party and the cancellation shall take effect on the giving of such notice.',
    "type": "sublabel",
    "value": "",

  },
  {
    "key": ' 13.2 he remedies in terms of this clause are without prejudice to any other remedies to which the innocent party may be entitled in law.',
    "type": "label",
    "value": "",

  },

]
export const FORM_TEMPLETE_GENERAL = [


  {
    "key": '14.1 This document constitutes the sole record of the agreement between the parties.',
    "type": "label",
    "value": "",

  },

  {
    "key": '14.2 No party shall be bound by any express or implied term representation, warranty, promise or the like not recorded herein.',
    "type": "label",
    "value": "",

  },
  {
    "key": '14.3  No  addition  to,  variation,  or  agreed  cancellation  of  this  agreement  shall  be  of  any  force  or effect unless in writing and signed by or on behalf of both parties.',
    "type": "label",
    "value": "",

  },
   {
     "key": '14.4 No  indulgence  which  either  party  may  grant  to  the  other  shall  constitute  a  novation  of  this agreement or a waiver of any of the rights of such party who shall not thereby be precluded from exercising any rights against the other party which may have arisen in the past or which might arise in the future',
    "type": "label",
    "value": "",

  },
   {
     "key": '14.5 Subject to and in terms of the provisions of Section 45 of the Magistrates’ Court Act, No. 32 of 1944,  as  amended,  the  parties  hereto  consent  and  agree  to  the  Magistrates’  Court  having jurisdiction  to  hear  and  determine  any  action  which  maybe  taken  by  either  of  the  parties against the other, arising out of or in connection with the Deed of Sale and in particular for the cancellation thereof;  irrespective of the amount or value of such claim or dispute and/or the residence, place of business or otherwise property jurisdiction or venue of the parties hereto, and  they  do  in  such  connections,  hereby  waive  any  objection    either  of  them  may  or  be entitled to advance to the jurisdiction of such Court.',
    "type": "label",
    "value": "",

  }

]


export const FORM_TEMPLETE_DOMICILE = [


  {
    "key": '15.1 The  parties  choose domicilium  citandi  et  executandi("domicilium")  for  the  purpose  of  the payment of any sum, the serving of any Court process and for any other purpose arising from this agreement as the property.',
    "type": "label",
    "value": "",

  },

  {
    "key": '15.2 Any notice given and any payment made by eitherparty to the other ("the addressee") which is  delivered  by  hand  during  the  normal  business  hours  of  the  addressee  at  the  address domiciliumfor  the  time  being, shall  be  presumed, until  the  contrary  is  proved  by  the addressee, to have been received by the addressee at the time of delivery.',
    "type": "label",
    "value": "",

  }]



export const FORM_TEMPLETE_OTHER_TERM_CONDITION = [


  
  {
    "key": ' Other Term Condition',
    "type": "textarea",
    "value": "otherTermCondition",

  },
  {
    "key": 'Term Condition Date',
    "type": "date",
    "value": "termConditionDate",
  },
  
  

]

export const FORM_TEMPLETE_AGENT = [


  {
    "key": '12.1 The  Seller  shall  pay  Agent  brokerage  calculated  at 7.5 % on  the  purchase  price, plus  VAT  at 14 %, which  agent  brokerage  shall  be  due  and  payable  on  transfer  or  cancellation in the circumstances contemplated in 12.2to12.4below:',
    "type": "label",
    "value": "",

  },

  {
    "key": '12.2 On transfer, or date of cancellation by mutual consent between the Seller and the Purchaser, the  Agent  may  appropriate  the  deposit  to  meet  its  brokerage  claim  and  is  such  deposit  is insufficient  and/or  is  heldby  the  conveyancers,  or  there  is  no  such  deposit,  then  the conveyancers  are  irrevocably  authorized  by  the  Seller  and  the  Purchaser  to  appropriate  the brokerage from either the deposit and/or funds held by the Conveyancers.',
    "type": "label",
    "value": "",

  },
  {
    "key": '12.3 If  the  agreement  is  cancelled  as  a  consequence  of  default  by  the  Purchaser,  the  Purchaser acknowledges  that  he/she  shall  be  liable  to  pay  the  agent  brokerage  by  way  of  liquidated damages  without  prejudice  to  the  rights  of  the  Agent  against  the  Seller  in  terms  of  this agreement.',
    "type": "label",
    "value": "",

  },
  {
    "key": '2.4 If   the agreement   is   cancelled   as   a   consequence   of   default   by   the   Seller,   the   Seller acknowledges  that  he/she/it  shall  be  immediately  liable  for  payment  of  the  brokerage contemplated herein.  Any legal costs incurred by the Agent in enforcing its right to brokerage against  the  seller  and/or  Purchaser  shall  be  paid  by  the  defendant  party  on  the  scale  as between attorney and client.',
    "type": "label",
    "value": "",

  },

]
export const FORM_TEMPLETE_WITTNESS = [



  {
    "key": ' Seller Witness',
    "type": "textBox",
    "value": "sellerWitness",

  },
  {
    "key": 'Date',
    "type": "date",
    "value": "witnessDate",
  },
  {
    "key": ' Purchaser Witness',
    "type": "textBox",
    "value": "purchaserWitness",

  },


]

export const ON_CHAIN_FORM_TEMPLETE_WITTNESS = [



  {
    "key": ' Seller Witness',
    "type": "textBox",
    "value": "sellerWitness",

  },
  {
    "key": 'Date',
    "type": "date",
    "value": "witnessDate",
  },
  {
    "key": ' Purchaser Witness',
    "type": "textBox",
    "value": "purchaserWitness",

  },

  {
    "key": 'Remark',
    "type": "textarea",
    "value": "remark",

  },
  {
    "key": 'Status',
    "type": "dropdown",
    "value": "status",

  },

]

