import { Component, OnInit, ViewChild, EventEmitter } from '@angular/core';
import { ON_CHAIN_COLUMN } from '../app.constant';
import { MatPaginator, MatTableDataSource, MatDialogConfig, MatSort } from '@angular/material';
import { MatDialog } from '@angular/material';
import { SellerDetail } from '../models/sellerdetail.interface';


import { EventService } from '../service/event/event.service';

import { NewEventDialogComponent } from '../dialog/new-event-dialog/new-event-dialog.component';

import { TicketDetailDialogComponent } from '../dialog/ticket-detail-dialog/ticket-detail-dialog.component';
import { AuthService } from '../service/auth/auth.service';
import { SearchResultPipe } from '../custom-filter/searchresult.pipe';
import { PAGINATOR_SIZE_ARRAY } from '../app.constant';
import { SelectboxService } from '../service/selectbox-clear/selectbox.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
//const FileSaver = require('file-saver');

@Component({
  selector: 'irm-case',
  templateUrl: './hostdashboard.component.html',
  styleUrls: ['./hostdashboard.component.scss']
})

export class HostDashboardComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  paginatorSize: number[] = PAGINATOR_SIZE_ARRAY;
  dropdownVal: string;
  showTransactionMessage = false;
  dataSource: MatTableDataSource<SellerDetail>;
  isLoadingResults: boolean;
  isSearchDone: boolean;
  showFlag: boolean;
  showSign: boolean;
  hideNoDataFound: boolean;
  message: string;
  isTransectionHashGenerated: EventEmitter<boolean> = new EventEmitter();
  columns = ON_CHAIN_COLUMN;
  displayedColumns = this.columns.map(x => x.key);



  defaultData: SellerDetail[];
  currentPersona: string;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private router: Router,
    private eventService: EventService,
    private authService: AuthService,
    private searchResultPipe: SearchResultPipe,
    private selectboxService: SelectboxService,
    private dialog: MatDialog) {
  }

  /**
   *
   * Initilising the list table with default data.
   * @memberof CaseComponent
   */
  ngOnInit() {
    this.resetTableData();
    this.currentPersona = this.authService.currentUserDetails.persona;
  
  }


  /**
   *
   * Initializing table data setting varibles default value
   * @param {CaseDetail[]} result
   * @memberof CaseComponent
   */
  initiliseTable(result: SellerDetail[]): void {
    this.hideNoDataFound = false;
    this.dataSource = new MatTableDataSource(result);
    this.dataSource.paginator = this.paginator;
    this.isLoadingResults = false;
  }

  
 

 
  resetTableData(): void {

    console.log("---insideresetTableData----");
    console.log("-ee---", this.authService.currentUserDetails)
    this.isLoadingResults = true;
    this.dropdownVal = '';
    this.selectboxService.isClear.next('');
    this.eventService.getAllEvent().subscribe(({ result }) => {
      this.defaultData = result;
      console.log("result", result);
      if (result.length === 0) {
        this.hideNoDataFound = true;
        this.isLoadingResults = false;
      } else {
        this.defaultData = this.defaultData.sort((first, second) => first.eventId > second.eventId ? -1 : 1);
        this.initiliseTable(result);
      }
    });
  }
  
  
  openNewEventPopup(): void {
    const dialogConfig = new MatDialogConfig();
    // dialogConfig.disableClose = true;
    this.dialog.open(NewEventDialogComponent, dialogConfig)
      .componentInstance
      .isTransectionHashGenerated
      .subscribe(result => { if (result) { this.resetTableData(); } });
  }
  
   
  openTicketDialog(row: SellerDetail): void {
    const dialogConfig = new MatDialogConfig();
    // dialogConfig.disableClose = true;
    dialogConfig.data = row;
    this.dialog.open(TicketDetailDialogComponent, dialogConfig)
              .componentInstance
              .isTransectionHashGenerated
              .subscribe(result => { if (result)  { this.resetTableData(); }});
  }
   
  }

 
