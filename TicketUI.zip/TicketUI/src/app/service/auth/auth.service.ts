import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Http } from '@angular/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { JWT_TOKEN_KEY, THEME_KEY, LOGIN_API, APP_KEY } from '../../app.constant';
import Utils from '../../utils';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: Http) { }

  login(credentials) {
    const userDetails = {
      ...credentials,
      subscriptionKey: APP_KEY
    };
    return this.http.post(LOGIN_API, userDetails)
      .map(response => {
        const result = response.json();
        if (result && result.token) {
        sessionStorage.setItem(JWT_TOKEN_KEY, result.token);
          return true;
       }
        return true;
      })
      .catch(Utils.handleError);
  }

  logout() {
    sessionStorage.removeItem(JWT_TOKEN_KEY);
    sessionStorage.removeItem(THEME_KEY);
  }

  isLoggedIn() {
    const jwtHelper = new JwtHelperService();
    const token = sessionStorage.getItem(JWT_TOKEN_KEY);
    if (!token) {
      return false;
    }

    return true;
    // const expirationDate = jwtHelper.getTokenExpirationDate(token);
    // const isExpired = jwtHelper.isTokenExpired(token);
    // console.log('isLoggedIn isExpired  ', isExpired);

    // return !isExpired;
    // return tokenNotExpired();
    // This method will do the same thing explained above.
    // Only diffrence is token value is not taken from sessionStorage
  }

  get currentUserDetails() {
    const token = sessionStorage.getItem('token');
    if (!token) { return null; }
    return new JwtHelperService().decodeToken(token);
  }
}