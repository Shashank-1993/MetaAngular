import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { JWT_TOKEN_KEY, SELLER_API, SELLER_LISTING_API, SELLER_PROPERTY_TO_AGENT, UPDATE_AGENT_RATE_API, GET_SELLER_DETAILS_BY_PROPERTY_ID_API} from '../../app.constant';
import Utils from '../../utils';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private http: Http) { }

  getAllSellerData(updateObj) {
    console.log("updateObj--->", updateObj)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${SELLER_LISTING_API}/${updateObj}`;
    // When we use authHttp all this code is already written in the library.
    var resp=this.http.get(url, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
    console.log("seller resp", resp);
    return resp;
  }

  updateSeller(updateObj) {
    console.log("ups", updateObj);
    const headers = new Headers();
    const url = `${SELLER_API}/${updateObj.propertyId}`;
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(url, updateObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  createSeller(createObj) {
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(SELLER_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  sendToAgent(propertyId, updateObj) {
    console.log("propertyId-----", propertyId);
    console.log("updateObj-----", updateObj);
    const headers = new Headers();
    const url = `${SELLER_PROPERTY_TO_AGENT}/${propertyId}`;
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(url, updateObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  
  updateAgentRate(updateObj) {
    console.log("ups", updateObj);
    const headers = new Headers();
    const url = `${UPDATE_AGENT_RATE_API}/${updateObj.propertyId}`;
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(url, updateObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  getSellerDetailsByPropertyId(propertyId) {
    console.log("updateObj--->", propertyId)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${GET_SELLER_DETAILS_BY_PROPERTY_ID_API}/${propertyId}`;
    // When we use authHttp all this code is already written in the library.
    var resp = this.http.get(url, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
    console.log("seller resp", resp);
    return resp;
  }
}
