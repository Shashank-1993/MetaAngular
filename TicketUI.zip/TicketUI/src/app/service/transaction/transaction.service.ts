import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { JWT_TOKEN_KEY, TRANSACTION_API, DETAILS_BY_TRANSACTION_ID} from '../../app.constant';
import Utils from '../../utils';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  constructor(
    private http: Http) { }

  getAllTransactionDetailsByProperyId(applicationId) {
    console.log("propertyId--->", applicationId)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${TRANSACTION_API}/${applicationId}`;
    // When we use authHttp all this code is already written in the library.

    var resp = this.http.get(url, options).map(response => JSON.parse(response['_body'])).catch(Utils.handleError);

    console.log("respppp", resp);
    return resp;
  }
  getDetailsByTransactionId(transactionId) {
    console.log("transactionId--->", transactionId)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${DETAILS_BY_TRANSACTION_ID}/${transactionId}`;
    // When we use authHttp all this code is already written in the library.

    var resp = this.http.get(url, options).map(response => JSON.parse(response['_body'])).catch(Utils.handleError);

    console.log("respppp", resp);
    return resp;
  }

 
}
