import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { DEFAULT_THEME } from '../../app.constant';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  public theme: BehaviorSubject<string>     = new BehaviorSubject(DEFAULT_THEME);
}
