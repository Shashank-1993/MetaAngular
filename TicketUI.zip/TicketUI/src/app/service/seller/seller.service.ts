import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, ResponseContentType } from '@angular/http';
import { UPDATE_PRE_GRANT_STATUS_API, GET_APPLICATION_FORM_API, UPDATE_DOCUSIGN_STATUS_API,GET_BUYER_FILE_DOWNLOAD_API, JWT_TOKEN_KEY, SELLER_API, WITNESS_API, UPDATE_STATUS_API, ONCHAIN_SELLER_DATA_API, ONCHAIN_BUYER_DATA_API, FIXTURE_API, SUSPENSIVE_API, OFFCHAIN_DATA_API, OTHER_TEAM_CONDITION_API, OCUPATION_API,SELLER_PROPERTY_DETAILS_API, OFFER_DATE_API, SELLER_LISTING_API, SELLER_PROPERTY_TO_AGENT, UPDATE_AGENT_RATE_API, GET_SELLER_DETAILS_BY_PROPERTY_ID_API} from '../../app.constant';
import Utils from '../../utils';
import { HttpParams } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class SellerService {

  constructor(
    private http: Http) { }

  getAllSellerData(updateObj) {
    console.log("updateObj--->", updateObj)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${SELLER_LISTING_API}/${updateObj}`;
    // When we use authHttp all this code is already written in the library.
    var resp=this.http.get(url, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
    console.log("seller resp", resp);
    return resp;
  }
  getOffChainData(applicationId) {
    console.log("getOffChainData--->", applicationId)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${OFFCHAIN_DATA_API}/${applicationId}`;
    // When we use authHttp all this code is already written in the library.
    var resp = this.http.get(url, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
    console.log("seller resp", resp);
    return resp;
  }
  
  updateSeller(updateObj) {
    console.log("ups", updateObj);
    const headers = new Headers();
    const url = `${SELLER_API}/${updateObj.propertyId}`;
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(url, updateObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  createSeller(createObj) {

    console.log("------seller", createObj, SELLER_API)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(SELLER_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  createPropertyDetails(createObj) {

    console.log("------propertydetails", createObj, SELLER_API)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(SELLER_PROPERTY_DETAILS_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  createOfferDate(createObj) {
    console.log("offerDate----", createObj)
   
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(OFFER_DATE_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  
  createSuspensiveCondition(createObj) {
    console.log("offerDate----", createObj)

    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(SUSPENSIVE_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  createOccupationCondition(createObj) {
    console.log("offerDate----", createObj)

    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(OCUPATION_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  createFixture(createObj) {
    console.log("offerDate----", createObj)

    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(FIXTURE_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  createOtherTermCondition(createObj) {
    console.log("otherTermCondition----", createObj)

    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(OTHER_TEAM_CONDITION_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  createWitness(createObj) {
    console.log("otherTermCondition----", createObj)

    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(WITNESS_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  updateStatus(createObj) {
    console.log("otherTermCondition----", createObj)

    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(UPDATE_STATUS_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  updatePregrantStatus(createObj) {
    console.log("otherTermCondition----", createObj)

    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(UPDATE_PRE_GRANT_STATUS_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  

  sendToAgent(propertyId, updateObj) {
    console.log("propertyId-----", propertyId);
    console.log("updateObj-----", updateObj);
    const headers = new Headers();
    const url = `${SELLER_PROPERTY_TO_AGENT}/${propertyId}`;
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(url, updateObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }
  
 
  getSellerDetailsByPropertyId(propertyId) {
    console.log("updateObj--->", propertyId)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${GET_SELLER_DETAILS_BY_PROPERTY_ID_API}/${propertyId}`;
    // When we use authHttp all this code is already written in the library.
    var resp = this.http.get(url, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
    console.log("seller resp", resp);
    return resp;
  }
  getApplicationFormByApplicationId(applicationId) {
    console.log("updateObj--->", applicationId)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${GET_APPLICATION_FORM_API}/${applicationId}`;
    // When we use authHttp all this code is already written in the library.
    var resp = this.http.get(url, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
    console.log("seller resp", resp);
    return resp;
  }
  

  getAllProcessedApplication(userId, persona) {
    var API_URL;
    if (persona == 'Seller') {
      API_URL = ONCHAIN_SELLER_DATA_API;
    } else if (persona == 'Buyer') {
      API_URL = ONCHAIN_BUYER_DATA_API;
    } 
    console.log("updateObj--->", userId)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${API_URL}/${userId}`;
    // When we use authHttp all this code is already written in the library.
    var resp = this.http.get(url, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
    console.log("seller resp", resp);
    return resp;
  }


  getBuyerDownloadFile(fileName) {
    console.log("UrlPath--->", fileName)
    const headers = new Headers();
   
    //headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
   // headers.append('Content-Type', 'text/html');
    headers.append('Access-Control-Allow-Origin', '*');
    headers.append('Access-Control-Allow-Methods', 'GET');
    headers.append('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Auth-Token');
    const options = new RequestOptions({ headers, responseType: ResponseContentType.Blob   });
    const url = `${GET_BUYER_FILE_DOWNLOAD_API}?filename=${fileName}`
    console.log("url---", url);
    var resp = this.http.get(url, options)

      //.map(response => JSON.parse(response['_body']))
      .map(response => new Blob([resp.blob()], { type: 'text/html' }))
     .catch(Utils.handleError);
    console.log("respp------------>", resp)
 // window.URL.createObjectURL(resp)
    window.open(url, '_blank');
    return resp;

  }

  updateDocuSignStatus(createObj) {
    console.log("otherTermCondition----", createObj)

    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(UPDATE_DOCUSIGN_STATUS_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

}
