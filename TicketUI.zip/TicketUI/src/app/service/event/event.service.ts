import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, ResponseContentType } from '@angular/http';
import { HttpParams } from "@angular/common/http";
import { JWT_TOKEN_KEY, CREATE_EVENT_API,FINDALL_EVENT_API,ALL_BUYER_LIST_API, PURCHASE_PRICE_API,  ALL_BUYER_DASHBOARD_API, SEND_TO_BUYER_API, ALL_BUYER_REMARK_LIST_API, UPDATE_SELLER_REMARK_API, GET_BUYER_DETAILS_BY_BUYER_ID_API, GET_BUYER_FILE, UPDATE_BUYER_API} from '../../app.constant';
import Utils from '../../utils';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor(
    private http: Http) { }

  


    getAllEvent() {
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
  //  const url = `${ALL_BUYER_DASHBOARD_API}/${updateObj}`;
    const options = new RequestOptions({ headers });
    // When we use authHttp all this code is already written in the library.
    return this.http.get(FINDALL_EVENT_API, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
  }

  /*updateAgent(updateObj) {
    const headers = new Headers();
   
    const url = `${BUYER_API}/${updateObj.agentId}`;
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(url, updateObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }*/

  /*createBuyer(createObj) {
    
   
    const headers = new Headers();
   
    const formData: FormData = new FormData();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
   
     formData.append('myfile', createObj.profile, createObj.profile.name );
     const details = {
       "amount": createObj.amount,
       "buyerAddress": createObj.buyerAddress,
       "buyerMobileno": createObj.buyerMobileno,
       "buyerRemarks": createObj.buyerRemarks,
       "propertyId": createObj.propertyId
    };

   //formData.append('buyerdetails', new Blob([JSON.stringify(details)], { type: 'application/json' }));
    formData.append('buyerdetails', JSON.stringify(createObj));
    //formData.append('buyerMobileno', createObj.buyerMobileno);
   // formData.append('buyerRemarks', createObj.buyerRemarks);
   // formData.append('propertyId', createObj.propertyId);
   

    console.log("formData------", formData.getAll('amount'));
  // headers.append('Content-Type', 'multipart/form-data');
    return this.http.post(BUYER_API, formData, {headers})
      .map(response => response.json())
      .catch(Utils.handleError);
  }*/
  /*createBuyer(createObj) {
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.post(BUYER_API, createObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }*/
 
  
 /* createEvent1(createObj) {
console.log("----")

    const headers = new Headers();

    const formData: FormData = new FormData();
    

    formData.append('myfile', createObj.profile, createObj.profile.name);
    

    //formData.append('buyerdetails', new Blob([JSON.stringify(details)], { type: 'application/json' }));
    //formData.append('buyerdetails', JSON.stringify(createObj));
    //formData.append('buyerMobileno', createObj.buyerMobileno);
    // formData.append('buyerRemarks', createObj.buyerRemarks);
    // formData.append('propertyId', createObj.propertyId);


    //console.log("formData11111------", formData.getAll('amount'));
    // headers.append('Content-Type', 'multipart/form-data');
    return this.http.put(EVENT_API, formData, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }*/

  createEvent(createObj) {

    const formData: FormData = new FormData();
    formData.append('myfile', createObj.profile, createObj.profile.name);
    const headers = new Headers();
   // headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
   // headers.append('Content-Type', 'application/json');
    formData.append('eventdetails', JSON.stringify(createObj));
    return this.http.post(CREATE_EVENT_API, formData, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  sendToBuyer(agentId, updateObj) {
    console.log("agentId-----", agentId);
    console.log("updateObj-----", updateObj);
    const headers = new Headers();
    const url = `${SEND_TO_BUYER_API}/${agentId}`;
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(url, updateObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  updateSellerRemark(updateObj) {

    console.log("updateObj-----", updateObj);
    const headers = new Headers();
    const url = `${UPDATE_SELLER_REMARK_API}/${updateObj.buyerId}`;
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    return this.http.put(url, updateObj, { headers })
      .map(response => response.json())
      .catch(Utils.handleError);
  }

  getBuyerDetailsByBuyerId(buyerId) {
    console.log("updateObj--->", buyerId)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/json');
    const options = new RequestOptions({ headers });
    const url = `${GET_BUYER_DETAILS_BY_BUYER_ID_API}/${buyerId}`;
    // When we use authHttp all this code is already written in the library.
    var resp = this.http.get(url, options)
      .map(response => JSON.parse(response['_body']))
      .catch(Utils.handleError);
    console.log("seller resp", resp);
    return resp;
  }

  getBuyerDownloadFile(UrlPath) {
    console.log("UrlPath--->",UrlPath)
    const headers = new Headers();
    headers.append('authorization', 'Bearer ' + sessionStorage.getItem(JWT_TOKEN_KEY));
    headers.append('Content-Type', 'application/pdf');
    headers.append('Access-Control-Allow-Origin', '*');
    const options = new RequestOptions({ headers, responseType: ResponseContentType.Blob  });
    const url = `${GET_BUYER_FILE}/${UrlPath}`;
    var resp = this.http.get(url, options)
      //.map(response => JSON.parse(response['_body']))
            .map(response => new Blob([response.blob()], { type: 'application/pdf' }))
      .catch(Utils.handleError);
    return resp;

  }


  
}
