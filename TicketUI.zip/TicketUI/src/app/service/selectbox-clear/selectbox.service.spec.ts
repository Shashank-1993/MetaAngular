import { TestBed, inject } from '@angular/core/testing';

import { SelectboxService } from './selectbox.service';

describe('SelectboxService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SelectboxService]
    });
  });

  it('should be created', inject([SelectboxService], (service: SelectboxService) => {
    expect(service).toBeTruthy();
  }));
});
