import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})
export class SelectboxService {
  public isClear: BehaviorSubject<string>     = new BehaviorSubject('');
}
