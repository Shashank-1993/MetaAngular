import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'datefilter'
})
export class DatefilterPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    const newDate = new Date(Number(value)).toString();
    const dateArry = newDate.split(' ');
    const timeArry = dateArry[4].split(':');
    return `${dateArry[2]}-${dateArry[1]}-${dateArry[3]} ${timeArry[0]}:${timeArry[1]}`;
  }

}
