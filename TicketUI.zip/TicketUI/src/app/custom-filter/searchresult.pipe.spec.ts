import { SearchResultPipe } from './searchresult.pipe';

describe('SearchdataPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchResultPipe();
    expect(pipe).toBeTruthy();
  });
});
