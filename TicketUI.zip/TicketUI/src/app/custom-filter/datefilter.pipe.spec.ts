import { DatefilterPipe } from './datefilter.pipe';

describe('DatefilterPipe', () => {
  const date = new Date(2018, 7, 1, 20, 30);
  it('create an instance', () => {
    const pipe = new DatefilterPipe();
    expect(pipe).toBeTruthy();
  });

  it('no locations in the list', () => {
    const pipe = new DatefilterPipe();
    const response   = pipe.transform(date);
    expect(response).toContain('01-Aug-2018 20:30');
  });
});
