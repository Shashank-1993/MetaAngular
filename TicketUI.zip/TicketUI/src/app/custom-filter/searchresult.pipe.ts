import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchdata'
})
export class SearchResultPipe implements PipeTransform {
  transform(value: any, searchValue: string, searchType: string): any {
    return value.filter(ele => ele[searchType] ? ele[searchType].toLowerCase().indexOf(searchValue.toLowerCase()) > -1 : false);
  }
}
