import { Component } from '@angular/core';

@Component({
  selector: 'irm-noaccess',
  templateUrl: './noaccess.component.html',
  styleUrls: ['./noaccess.component.scss']
})
export class NoAccessComponent {

  constructor() { }
}