import { Component, OnInit } from '@angular/core';
import { AuthService } from '../service/auth/auth.service';
import { Router } from '@angular/router';
import { ThemeService } from '../service/theme/theme.service';
import { DEFAULT_THEME } from '../app.constant';
import { MatPaginator, MatTableDataSource, MatDialogConfig } from '@angular/material';
import { MatDialog } from '@angular/material';


@Component({
  selector: 'irm-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  currentUser: string;
  currentPersona: string;
  constructor(
    private router: Router,
    private dialog: MatDialog,
    private themeService: ThemeService,
    private authService: AuthService) { }

  /**
   *
   * Initializing user details.
   * @memberof HeaderComponent
   */
  ngOnInit() {
   // this.currentUser = this.authService.currentUserDetails.name;
    //this.currentPersona = this.authService.currentUserDetails.persona;
  }

/**
   *
   * Setting default theme and re-directing to logout.
   * @memberof HeaderComponent
   */
  logout(): void {
    this.themeService.theme.next(DEFAULT_THEME);
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  /**
   *
   * Checking user logged-in.
   * @returns {boolean}
   * @memberof HeaderComponent
   */
  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  resetTableData(): void {
  }

 
}
