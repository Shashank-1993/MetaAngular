import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { HeaderComponent } from './header.component';
import { ThemeService } from '../service/theme/theme.service';
import { AuthService } from '../service/auth/auth.service';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

class ThemeServiceMock {
  public theme: BehaviorSubject<string> = new BehaviorSubject('default-theme');
}

class AuthServiceMock {
  get currentUserDetails() {
    return {
      name: 'Willson'
    };
  }
  logout() {}
  isLoggedIn() {}
}

class RoutereMock {

}
describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let themeService: ThemeService;
  let authService: AuthService;
  let authGetSpy;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderComponent ],
      schemas: [ NO_ERRORS_SCHEMA ],
      providers: [{ provide: ThemeService, useClass: ThemeServiceMock },
                  { provide: AuthService, useClass: AuthServiceMock },
                  { provide: Router, useClass: RoutereMock } ]
    })
    .compileComponents()
    .then(() => {
      fixture = TestBed.createComponent(HeaderComponent);
      component = fixture.componentInstance;
      themeService = fixture.debugElement.injector.get(ThemeService);
      authService = fixture.debugElement.injector.get(AuthService);
    });
  }));

  beforeEach(() => {
      authGetSpy = spyOn(authService, 'currentUserDetails')
      .and
      .returnValue({
        name: 'Willson'
      });
      authGetSpy = spyOn(authService, 'isLoggedIn')
      .and
      .returnValue(true);
    }
  );

  it('setting current username', async(() => {
    fixture.detectChanges();
    expect(component.currentUser).toContain('test');
  }));

  it('logout check current theme', async(() => {
    component.logout();
    // expect().toContain('Wilson');
  }));

  it('is user loggedin', async(() => {
    expect(component.isLoggedIn()).toBeTruthy();
  }));
});
