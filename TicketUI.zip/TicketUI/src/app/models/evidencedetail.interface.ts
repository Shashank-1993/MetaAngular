export interface EvidenceDetail {
    evidenceId: number;
    caseId: number;
    createdBy: string;
    evidenceDescription: string;
    ownerProperties: string;
    evidenceRoomId: string;
    RFID: string;
    evidenceTimestamp: string;
    status: string;
    // Not Part of Data Base
    nextCustodianTrack: {
        isReceived: boolean,
        isTransfered: boolean
    };
}
