export interface BuyerDetail {
  applicationId:  String;
  buyerFullName: string ;
  buyerPassportNumber: string ;
  buyerSpouseName: string ;
  buyerMaritalStatus: string ;
  buyerPostalAddress: string ;
  buyerEmail: string ;
  buyerPhoneNumber: string ;
  buyerFaxNumber: string ;
  buyerSarstaxNumber: string ;
  buyerVatnumber: string ;
  buyerConveyancers: string ;
  buyerPropertyBonded: string ;
  buyerBondedAccountNumber: string;
  progressCount: number;
 
 
}

