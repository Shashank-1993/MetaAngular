export interface StateDetail {
    stateId: string;
    evidenceId: number;
    createdBy: string;
    userName: string;
    evidenceStatus: string;
    createdTimestamp: string;
    address: string;
    city: string;
    state: string;
    receiverBuildingName: string;
    receiverOfficeName: string;
    zipCode: string;
    transporterName: string;
    receiverName: string;
    reasonFortransaction: string;
    auditId: string;
}

