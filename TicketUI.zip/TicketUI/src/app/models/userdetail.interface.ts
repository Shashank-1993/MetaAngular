export interface UserDetail {
 
  firstName: string; 
lastName: string;
userName: string;
sellerRemark: string;
 createdDate: string;
 status: string;
  sellerMobileno: string;
  propertyPrice: string;
  sendToAgent: string;
  agentCommission: string;
  commissionComment: string;

 
}

