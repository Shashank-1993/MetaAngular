export interface TransactionDetail {
   propertyId: number;
    transactionId: string;
    blockNo: string;
    transactionTimeStamp: string;
  userName: string;
  operationType: string;
}

