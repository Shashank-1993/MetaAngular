export interface AgentDetail {
  agentId: number;
  propertyId: number;
  createdBy: string; 
  agentAddress: string;
  agentRemark: string;
  createdDate: string;
  status: string;
  agentMobile: string;
 
}

