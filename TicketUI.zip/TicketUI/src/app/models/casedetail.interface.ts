export interface CaseDetail {
  caseId: number;
    caseName: string;
    caseDescription: string;
    caseTimestamp: string;
    caseStatus: string;
    offenseTimestamp: string;
  createdBy: string;
  propertyName: string;
  propertydesc: String;
  Agent: String;
}

