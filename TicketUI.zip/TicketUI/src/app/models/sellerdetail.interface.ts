export interface SellerDetail {
  eventId: number;
   eventName: string; 
  eventDescription: string;
   eventDate: string;
   imageHash:string;
 
 
}

