import { Routes, RouterModule } from '@angular/router';




import { LoginComponent } from './login/login.component';
import { NoAccessComponent } from './noaccess/noaccess.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './service/auth-guard/auth-guard.service';
import { HostDashboardComponent } from './hostdashboard/hostdashboard.component';
import { UserDashboardComponent } from './userdashboard/userdashboard.component';



const appRoutes: Routes = [
  {
    path: '',
    children: [
     
      {
        path: 'hostdashboard',
        component: HostDashboardComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'userdashboard',
        component: UserDashboardComponent,
        canActivate: [AuthGuard]
      },
      

      
      
      

      
      
     
      
      { path: '', redirectTo: 'case', pathMatch: 'full' },

      ],
    component: HomeComponent,
    canActivate: [AuthGuard]
  },
  { path: 'login', component: LoginComponent },
  { path: '**', component: NoAccessComponent },
 
 

 
];

export const Routing = RouterModule.forRoot(appRoutes, {
  useHash: true,
  scrollPositionRestoration: 'enabled'
});
