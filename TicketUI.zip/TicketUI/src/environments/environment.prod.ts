export const environment = {
  production: true,
  version: 'Prod'
};
